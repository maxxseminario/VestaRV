#!/usr/bin/env python3

from MemoryMap import MemoryMap
from Peripheral import PeripheralTemplate, Peripheral
from Register import RegisterTemplate, Register
from BitField import BitField
from PinConfigurator import PinConfigurator

''' Create Memory Map '''
m = MemoryMap(
	asicName='teewinot',
	romStartAddress=0x0000,
	romSize=8192,	# 8 KiB
	peripheralMemoryStartAddress=0x4000,
	peripheralMemorySlotCount=32,
	registerMemorySlotsPerPeripheralMemorySlot=64,
	ramStartAddress=0x8000,
	ramMemorySlotSize=16384,	# 16 KiB
	ramMemorySlotsAvailable=[2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
	ramMemorySlotsUsed=[2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
	ramMemorySlotsMuxed=[7, 8, 9, 10, 11],	# The RAM slots that are MUXed with some peripheral that the program may not always use for whatever it wants.
	stackPointerInit=0x1C000,	# TODO: Make sure the initial stack pointer is not in the NPU MUXed RAM block or the AFE MUXed RAM blocks.
	vectorsCount=32,
	padOutPosLogic=True,
	padDIRPosLogic=False,
	padRENPosLogic=False,
	#padOCENPosLogic=True,
	ENABLE_REGS_DUALPORT=True,	# TODO: Enable for ASIC synthesis if using a dual port register file, disable for Xilinx Spartan 6 FPGAs
	TWO_STAGE_SHIFT=True,
	BARREL_SHIFTER=True,
	COMPRESSED_ISA=True,
	ENABLE_MUL=True,
	ENABLE_FAST_MUL=True,
	ENABLE_DIV=True,
	ENABLE_IRQ_QREGS=True,	# TODO: In the file hdl/picorv32/picorv32_cpuregs, ensure that ENABLE_IRQ_REGS is this same here as there. Evidently the ARM register file IPs are called "two-port", but one port is read-only and the other is write-only. This means you need to write your own register file definition in HDL (remember that register x0 is always all '0's!)
	MASKED_IRQ=0x00000000,	# TODO: 32-bit IRQ mask. Any bit that is a '1' is a permanently disabled interrupt vector
	PROGADDR_IRQ=0x8090		# TODO: Set this as the address of the master IRQ handling function (this is NOT the interrupt vector table!!! This is the function that is called whenever ANY interrupt occurs)
)



''' System '''
p = PeripheralTemplate(nameTemplate='SYSTEM', description='Controls the entire system, including the clocking and power state. Also has a CRC calculator using the CRC16_CDMA2000 polynomial.')
m.AddPeripheralTemplate(p)

# SYSCLK
r = RegisterTemplate(nameTemplate='SYSCLKCR', registerMemorySlot=0, description='System clock control register', size=16)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='CLKOSSEL', msb=15, lsb=13, description='CLKO pin output clock source select', accessibility='rw', valueDescriptions=[(0b000, 'CPU Clock', '_CPU'), (0b001, 'mclk', '_MCLK'), (0b010, 'smclk', '_SMCLK'), (0b011, 'Low Frequency Crystal Clock', '_LFXT'), (0b100, 'High Frequency Crystal Clock', '_HFXT'), (0b101, 'Digitally Controlled Oscillator 0', '_DCO0'), (0b110, 'Digitally Controlled Oscillator 1', '_DCO1')]))
r.AddBitField(BitField(unused=True, msb=12))
r.AddBitField(BitField(name='DCO1OFF', msb=11, description='Enables/disables the digitally controlled oscillator 1 (DCO1) clock. Cannot be disabled if it is being used as a source to the CPU clock or smclk, even if this bit is set to disable mode.', accessibility='rw', valueDescriptions=[(0b0, 'Enabled and Powered On'), (0b1, 'Disabled and Powered Down')]))
r.AddBitField(BitField(name='DCO0OFF', msb=10, description='Enables/disables the digitally controlled oscillator 0 (DCO0) clock. Cannot be disabled if it is being used as a source to the CPU clock or smclk, even if this bit is set to disable mode.', accessibility='rw', valueDescriptions=[(0b0, 'Enabled and Powered On'), (0b1, 'Disabled and Powered Down')]))
r.AddBitField(BitField(name='HFXTOFF', msb=9, description='Enables/disables the high frequency crystal clock. Cannot be disabled if it is being used as a source to the CPU clock or smclk, even if this bit is set to disable mode.', accessibility='rw', valueDescriptions=[(0b0, 'Enabled'), (0b1, 'Disabled')]))
r.AddBitField(BitField(name='LFXTOFF', msb=8, description='Enables/disables the low frequency crystal clock. Cannot be disabled if it is being used as a source to smclk, even if this bit is set to disable mode.', accessibility='rw', valueDescriptions=[(0b0, 'Enabled'), (0b1, 'Disabled')]))
r.AddBitField(BitField(name='CPUOFF', msb=7, description='Enables/disables the CPU clock. This is the main vehicle for putting the CPU to sleep. The CPU clock (and the clock that the CPU clock is currently sourced from in MCLKSEL) is automatically enabled during interrupts, even if this bit is set to disable mode.', accessibility='rw', valueDescriptions=[(0b0, 'Enabled'), (0b1, 'Disabled')]))
r.AddBitField(BitField(name='SMCLKOFF', msb=6, description='Enables/disables the submain clock. This is the main vehicle for putting the peripherals to sleep. The MCU is not aware of which peripherals are currently using smclk, and in consequence, setting this bit to disable mode will globally and absolutely shut down smclk.', accessibility='rw', valueDescriptions=[(0b0, 'Enabled'), (0b1, 'Disabled')]))
r.AddBitField(BitField(unused=True, msb=5))
r.AddBitField(BitField(name='SMCLKSEL', msb=4, lsb=3, description='Submain clock source select', accessibility='rw', valueDescriptions=[(0b00, 'High Frequency Crystal Clock', '_HFXT'), (0b01, 'Low Frequency Crystal Clock', '_LFXT'), (0b10, 'Digitally Controlled Oscillator 0', '_DCO0'), (0b11, 'Digitally Controlled Oscillator 1', '_DCO1')]))
r.AddBitField(BitField(unused=True, msb=2))
r.AddBitField(BitField(name='MCLKSEL', msb=1, lsb=0, description='Main clock source select (also CPU clock source select)', accessibility='rw', valueDescriptions=[(0b00, 'High Frequency Crystal Clock', '_HFXT'), (0b01, 'Submain Clock', '_SMCLK'), (0b10, 'Digitally Controlled Oscillator 0', '_DCO0'), (0b11, 'Digitally Controlled Oscillator 1', '_DCO1')]))

# CLKDIVCR
r = RegisterTemplate(nameTemplate='CLKDIVCR', registerMemorySlot=1, description='MCLK and SMCLK clock divider control register', size=8)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=7, lsb=6, unused=True))
r.AddBitField(BitField(name='SMCLKDIV', msb=5, lsb=3, accessibility='rw', description='SMCLK clock division selection', valueDescriptions=[(0b000, '/1 (no division)', '_1'), (0b001, '/4', '_4'), (0b010, '/16', '_16'), (0b011, '/64', '_64'), (0b100, '/128', '_128'), (0b101, '/256', '_256'), (0b110, '/512', '_512'), (0b111, '/1,024', '_1024')]))
r.AddBitField(BitField(name='MCLKDIV', msb=2, lsb=0, accessibility='rw', description='MCLK clock division selection', valueDescriptions=[(0b000, '/1 (no division)', '_1'), (0b001, '/4', '_4'), (0b010, '/16', '_16'), (0b011, '/64', '_64'), (0b100, '/128', '_128'), (0b101, '/256', '_256'), (0b110, '/512', '_512'), (0b111, '/1,024', '_1024')]))

# MEMPWRCR
r = RegisterTemplate(nameTemplate='MEMPWRCR', registerMemorySlot=2, description='Memory power control register', size=16)
p.AddRegisterTemplate(r)

for i in reversed(range(2, 16)):
	sramName = 'SRAM' + '{:02}'.format(i)
	bfName = sramName + 'OFF'
	r.AddBitField(BitField(name=bfName, msb=i, description='Controls the power state of ' + sramName + '. When off, all memory in ' + sramName + ' becomes undefined, it no longer responds to read or write access, and leakage power consumption decreases.', accessibility='rw', valueDescriptions=[(0b0, 'Power on'), (0b1, 'Power off')]))
r.AddBitField(BitField(unused=True, msb=1))
r.AddBitField(BitField(name='ROMOFF', msb=0, description='Controls the power state of the boot ROM. When off, it no longer responds to read access, and leakage power consumption decreases.', accessibility='rw', valueDescriptions=[(0b0, 'Power on'), (0b1, 'Power off')]))

# CRCDATA
r = RegisterTemplate(nameTemplate='CRCDATA', registerMemorySlot=3, description='CRC input data register. Write the next byte of the data array to this register to continue calculating the CRC value of the data array.', size=8)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='CRCDATA', msb=7, lsb=0, accessibility='rw'))

# CRCSTATE
r = RegisterTemplate(nameTemplate='CRCSTATE', registerMemorySlot=4, description='CRC state register. Read this register to get the output of the CRC calculation. Write to this register to set the initial value of the CRC. Note that the value of this register is undefined during the time between when it is written to until when CRCDATA is written to.', size=16)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='CRCSTATE', msb=15, lsb=0, accessibility='rw'))

# DCOx
for i in range(0, 2):
	prefix = 'DCO' + str(i)
	
	# DCOxFREQ
	r = RegisterTemplate(nameTemplate=prefix + 'FREQ', registerMemorySlot=(5 + 0 + (i * 3)), size=16, description=(prefix + ' non-stabilized frequency register (manual frequency adjustment)'))
	p.AddRegisterTemplate(r)

	r.AddBitField(BitField(unused=True, msb=15, lsb=12))
	r.AddBitField(BitField(name=(prefix + 'MFREQ'), msb=11, lsb=0, accessibility='rw', description='12-bit manual frequency adjustment'))

	# DCOxSCR
	r = RegisterTemplate(nameTemplate=(prefix + 'SCR'), registerMemorySlot=(5 + 1 + (i * 3)), size=32, description=(prefix + ' frequency stabilization control register'))
	p.AddRegisterTemplate(r)
	
	r.AddBitField(BitField(unused=True, msb=31, lsb=21))
	r.AddBitField(BitField(name=(prefix + 'SEN'), msb=20, accessibility='rw', description=(prefix + ' stabilizer enable. When enabled, the DCO uses the value in ' + prefix + ' as an initial frequency value and then stabilizes the frequency to ' + prefix + 'T number of DCO clock cycles per LFXT clock cycle.'), valueDescriptions=[(0b0, 'Disabled (manual frequency adjust)'), (0b1, 'Enabled (automatic frequeny stabilization)')]))
	r.AddBitField(BitField(name=(prefix + 'LDIV'), msb=19, lsb=18, accessibility='rw', description='LFXT divider for ' + prefix + ' frequency stabilizer', valueDescriptions=[(0b00, '/1 (no division)', '_1'), (0b01, '/2', '_2'), (0b10, '/4', '_4'), (0b11, '/8', '_8')]))
	r.AddBitField(BitField(name=(prefix + 'ES'), msb=17, lsb=16, accessibility='rw', description=(prefix + ' stabilizer right shifter. The next frequency value is calculated by ' + prefix + 'NextFreq = (((' + prefix + 'T - ' + prefix + 'CyclesPerLFXTCycle) * ' + prefix + 'EM) >> ' + prefix + 'ES) + CurrentFreq')))
	r.AddBitField(BitField(name=(prefix + 'T'), msb=15, lsb=0, accessibility='rw', description=(prefix + ' target number of DCO clock cycles per LFXT clock cycle')))

	# DCOxSSR
	r = RegisterTemplate(nameTemplate=(prefix + 'SSR'), registerMemorySlot=(5 + 2 + (i * 3)), size=16, description=(prefix + ' frequency stabilization status register'))
	p.AddRegisterTemplate(r)

	r.AddBitField(BitField(unused=True, msb=15, lsb=13))
	r.AddBitField(BitField(name=(prefix + 'L'), msb=12, accessibility='r', description=(prefix + ' frequency stabilizer lock'), valueDescriptions=[(0b0, 'Not locked'), (0b1, 'Locked (target error is within +/- 8 ' + prefix + ' clock cycles')]))
	r.AddBitField(BitField(name=(prefix + 'SFREQ'), msb=11, lsb=0, accessibility='r', description=(prefix + ' stabilizer frequency output value')))

# BIASCR
r = RegisterTemplate(nameTemplate='BIASCR', registerMemorySlot=11, size=16, description='Global bias generator control register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(unused=True, msb=15, lsb=10))
r.AddBitField(BitField(name='UseExtBias', msb=9, accessibility='rw', description='Enables/disables external bias voltages. Note that this bit does not enable or disable the internal bias generator or DACs. Those must be toggled separately.', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='UseBiasDac', msb=8, accessibility='rw', description='Switches between using the bias generator voltages or bias DACs for the global bias voltages.', valueDescriptions=[(0b0, 'Uses bias generator'), (0b1, 'Uses DACs')]))
r.AddBitField(BitField(name='EnBiasBuf', msb=7, accessibility='rw', description='Enables/disables buffers on the internal global bias voltages.', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='EnBiasGen', msb=6, accessibility='rw', description='Enables/disables the internal bias generator.', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='BiasAdj', msb=5, lsb=0, accessibility='rw', description='Internal bias generator adjustment vector. Higher vector codes produce smaller currents. The nominal vector from simulation is decimal 37.'))

# BIASDBP
r = RegisterTemplate(nameTemplate='BIASDBP', registerMemorySlot=12, size=16, description='Global bias P DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(unused=True, msb=15, lsb=14))
r.AddBitField(BitField(name='BIASDBP', msb=13, lsb=0, accessibility='rw', description='DAC value'))

# BIASDBPC
r = RegisterTemplate(nameTemplate='BIASDBPC', registerMemorySlot=13, size=16, description='Global bias P cascode DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(unused=True, msb=15, lsb=14))
r.AddBitField(BitField(name='BIASDBPC', msb=13, lsb=0, accessibility='rw', description='DAC value'))

# BIASDBNC
r = RegisterTemplate(nameTemplate='BIASDBNC', registerMemorySlot=14, size=16, description='Global bias N cascode DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(unused=True, msb=15, lsb=14))
r.AddBitField(BitField(name='BIASDBNC', msb=13, lsb=0, accessibility='rw', description='DAC value'))

# BIASDBN
r = RegisterTemplate(nameTemplate='BIASDBN', registerMemorySlot=15, size=16, description='Global bias N DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(unused=True, msb=15, lsb=14))
r.AddBitField(BitField(name='BIASDBN', msb=13, lsb=0, accessibility='rw', description='DAC value'))


	
	
''' SPIx '''
p = PeripheralTemplate(nameTemplate='SPIx', description='Master-only Serial Peripheral Interface')
m.AddPeripheralTemplate(p)

# SPIxCR
r = RegisterTemplate(nameTemplate='SPIxCR', registerMemorySlot=0, description='SPI control register', size=16)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='SPIBR', msb=15, lsb=8, description='SPI clock (SCK) baud control. Baud rate = SMCLK / (2 * (1 + SPIBR))', accessibility='rw'))
r.AddBitField(BitField(name='SPIEN', msb=7, description='SPI enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='SPIMSB', msb=6, description='Endianness select', accessibility='rw', valueDescriptions=[(0b0, 'LSB first'), (0b1, 'MSB first')]))
r.AddBitField(BitField(name='SPITCIE', msb=5, description='SPI transmit complete interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Interrupt disabled'), (0b1, 'Interrupt enabled')]))
r.AddBitField(BitField(name='SPITEIE', msb=4, description='SPI transmit register empty interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Interrupt disabled'), (0b1, 'Interrupt enabled')]))
r.AddBitField(BitField(name='SPIDL', msb=3, lsb=2, description='SPI transmission data length select', accessibility='rw', valueDescriptions=[(0b00, '8-bit transfers', '_8'), (0b01, '16-bit transfers', '_16'), (0b10, '32-bit transfers', '_32')]))
r.AddBitField(BitField(name='SPICPOL', msb=1, description='SPI clock (SCK) polarity', accessibility='rw', valueDescriptions=[(0b0, 'SCK idles low, leading edge is a rising edge (for SPIMODE0 or SPIMODE1)'), (0b1, 'SCK idles high, leading edge is a falling edge (for SPIMODE2 or SPIMODE3)')]))
r.AddBitField(BitField(name='SPICPHA', msb=0, description='SPI clock (SCK) phase', accessibility='rw', valueDescriptions=[(0b0, 'Data is sampled on leading edge of SCK, data is updated on trailing edge of SCK (for SPIMODE0 or SPIMODE2)'), (0b1, 'Data is updated on leading edge of SCK, data is sampled on trailing edge of SCK (for SPIMODE1 or SPIMODE3)')]))

# SPIxSR
r = RegisterTemplate(nameTemplate='SPIxSR', registerMemorySlot=1, description='SPI status register', size=8)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=7, lsb=3, unused=True))
r.AddBitField(BitField(name='SPIBUSY', msb=2, description='Indicates if a SPI transfer is occurring or not', accessibility='r', valueDescriptions=[(0b0, 'A SPI transfer is not presently occurring'), (0b1, 'A SPI transfer is presently occurring')]))
r.AddBitField(BitField(name='SPITCIF', msb=1, description='SPI transmit complete interrupt flag. This bit is set when a SPI transfer has completed transmission and reception, and must be cleared in software before it can be set again.', accessibility='rw0', valueDescriptions=[(0b0, 'A SPI transmit has not been completed'), (0b1, 'A SPI transmit has been completed (must be cleared before it can be set again)')]))
r.AddBitField(BitField(name='SPITEIF', msb=0, description='SPI transmit register empty interrupt flag. This bit is set when the SPI transmit register SPIxTX is empty, and indicates SPIxTX is ready to accept new data for transmission (though the new data will not be transmitted until a current transmission is complete). Must be cleared in software before it can be set again.', accessibility='rw0', valueDescriptions=[(0b0, 'SPIxTX is not empty and is not ready for new data'), (0b1, 'SPIxTX is empty and ready for new data (must be cleared before it can be set again)')]))

# SPIxTX
r = RegisterTemplate(nameTemplate='SPIxTX', registerMemorySlot=2, description='SPI transmit buffer register. Write to this register to begin a SPI transfer.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='SPIxTX', msb=31, lsb=0, accessibility='rw'))

# SPIxRX
r = RegisterTemplate(nameTemplate='SPIxRX', registerMemorySlot=3, description='SPI receive buffer register. The received SPI data will appear in this register after each SPI transmission is complete.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='SPIxRX', msb=31, lsb=0, accessibility='r'))



''' GPIOx '''
p = PeripheralTemplate(nameTemplate='GPIOx', description='General Purpose Input Output')
m.AddPeripheralTemplate(p)

# PxIN
r = RegisterTemplate(nameTemplate='PxIN', registerMemorySlot=0, description='GPIO read pin register. Each bit corresponds to the input logic state of the GPIO pin of the same number at the time of the memory access reading this register (not synchronized to any clock). Reading a 0 in a bit indicates a logic low pin state; reading a 1 indicates a logic high state.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxIN', msb=31, lsb=0, accessibility='r'))

# PxOUT
r = RegisterTemplate(nameTemplate='PxOUT', registerMemorySlot=1, description='GPIO output drive register. Each bit corresponds to the output logic state of the GPIO pin of the same number. Only has an effect if the pin is configured as an output in PxDIR and is set to GPIO (primary) mode in PxSEL. Write a 0 to the desired bit to make the corresponding pin output a logic low value; write a 1 to output a logic high value.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxOUT', msb=31, lsb=0, accessibility='rw'))

# PxOUTS
r = RegisterTemplate(nameTemplate='PxOUTS', registerMemorySlot=2, description='GPIO output drive set register. Each bit corresponds to the output logic state of the GPIO pin of the same number. Only has an effect if the pin is configured as an output in PxDIR and is in GPIO (primary) mode in PxSEL. Write a 1 to the desired bit to set the corresponding pin (make the pin output a logic high value). Writing a 0 has no effect. Reading this register is equivalent to reading the output drive register PxOUT.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxOUTS', msb=31, lsb=0, accessibility='rw1'))

# PxOUTC
r = RegisterTemplate(nameTemplate='PxOUTC', registerMemorySlot=3, description='GPIO output drive clear register. Each bit corresponds to the output logic state of the GPIO pin of the same number. Only has an effect if the pin is configured as an output in PxDIR and is in GPIO (primary) mode in PxSEL. Write a 1 to the desired bit to clear the corresponding pin (make the pin output a logic low value). Writing a 0 has no effect. Reading this register yields the inversion of the output drive register PxOUT.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxOUTC', msb=31, lsb=0, accessibility='rw1'))

# PxDIR
r = RegisterTemplate(nameTemplate='PxDIR', registerMemorySlot=4, description='GPIO pin direction register. Each bit corresponds to the GPIO pin of the same number. Only has an effect if the pin is configured in GPIO (primary) mode in PxSEL. Write a 0 to the desired bit to set the corresponding pin to input mode; write a 1 to set to output mode.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxDIR', msb=31, lsb=0, accessibility='rw'))

# PxIFG
r = RegisterTemplate(nameTemplate='PxIFG', registerMemorySlot=5, description='GPIO interrupt flag register. Each bit corresponds to the GPIO pin of the same number. Reading a 0 in a bit indicates there is no pending interrupt for the corresponding pin; reading a 1 indicates there is a new interrupt pending for the corresponding pin. Write a 1 to each bit for which you wish to clear the interrupt flag.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxIFG', msb=31, lsb=0, accessibility='rw1'))

# PxIES
r = RegisterTemplate(nameTemplate='PxIES', registerMemorySlot=6, description='GPIO interrupt edge select register. Each bit corresponds to the GPIO pin of the same number. Write a 0 to the desired bit to set the corresponding pin interrupt rising edge triggering; write a 1 to set to falling edge triggering.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxIES', msb=31, lsb=0, accessibility='rw'))

# PxIE
r = RegisterTemplate(nameTemplate='PxIE', registerMemorySlot=7, description='GPIO interrupt enable register. Each bit corresponds to the GPIO pin of the same number. Only has an effect if the pin is configured in GPIO (primary) mode in PxSEL. Write a 0 to the desired bit to disable the pin interrupt; write a 1 to enable the pin interrupt.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxIE', msb=31, lsb=0, accessibility='rw'))

# PxSEL
r = RegisterTemplate(nameTemplate='PxSEL', registerMemorySlot=8, description='GPIO peripheral select register. Each bit corresponds to the GPIO pin of the same number. Write a 0 to the desired bit to set the corresponding pin to GPIO (primary) mode; write a 1 to set the pin to secondary function (peripheral) mode. When a pin is in secondary function (peripheral) mode, the governing peripheral takes control of the pin ouput, direction, resistor enable, and open-collector enable states, and the PxOUT, PxDIR, and PxREN have no effect on the pin. Note that pin interrupts are still available when in secondary function (peripheral) mode in addition to any interrupts the secondary function/peripheral may generate. Also note that not all pins necessarily have a secondary function; in this case, if the corresponding bit in PxSEL is set to 1, the pin will be configured as an input with the pullup resistor disabled and the open-collector mode disabled.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxSEL', msb=31, lsb=0, accessibility='rw'))

# PxREN
r = RegisterTemplate(nameTemplate='PxREN', registerMemorySlot=9, description='GPIO resistor enable register. Each bit corresponds to the GPIO pin of the same number. Only has an effect if the pin is configured in GPIO (primary) mode in PxSEL. Write a 0 to the desired bit to disable the pin pullup resistor; write a 1 to enable the pin pullup resistor.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PxREN', msb=31, lsb=0, accessibility='rw'))

## PxOCEN
#r = RegisterTemplate(nameTemplate='PxOCEN', registerMemorySlot=10, description='GPIO open collector register. Each bit corresponds to the GPIO pin of the same number. Only has an effect if the pin is configured in GPIO (primary) mode in PxSEL. Write a 0 to the desired bit to disable the pin open-collector mode; write a 1 to enable the pin open-collector mode.', size=32)
#p.AddRegisterTemplate(r)



''' UARTx '''
p = PeripheralTemplate(nameTemplate='UARTx', description='Full-duplex Universal Asynchronous Receiver/Transmitter serial port')
m.AddPeripheralTemplate(p)

# UARTxCR
r = RegisterTemplate(nameTemplate='UARTxCR', registerMemorySlot=0, description='UART control register', size=8)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=7, lsb=6, unused=True))
r.AddBitField(BitField(name='UEN', msb=5, description='UART enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='UPEN', msb=4, description='UART parity enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='UPODD', msb=3, description='UART parity select', accessibility='rw', valueDescriptions=[(0b0, 'Even parity'), (0b1, 'Odd parity')]))
r.AddBitField(BitField(name='URCIE', msb=2, description='UART receive complete interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Interrupt disabled'), (0b1, 'Interrupt enabled')]))
r.AddBitField(BitField(name='UTEIE', msb=1, description='UART transmit register empty interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Interrupt disabled'), (0b1, 'Interrupt enabled')]))
r.AddBitField(BitField(name='UTCIE', msb=0, description='UART transmit complete interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Interrupt disabled'), (0b1, 'Interrupt enabled')]))

# UARTxSR
r = RegisterTemplate(nameTemplate='UARTxSR', registerMemorySlot=1, description='UART status register', size=8)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='URBF', msb=7, description='UART receiver busy flag', accessibility='r', valueDescriptions=[(0b0, 'Receiver idle and ready for new reception'), (0b1, 'Receiver busy with ongoing reception')]))
r.AddBitField(BitField(name='UTBF', msb=6, description='UART transmitter busy flag', accessibility='r', valueDescriptions=[(0b0, 'Transmitter idle and ready for new transmission'), (0b1, 'Transmitter busy with ongoing transmission')]))
r.AddBitField(BitField(name='UFEF', msb=5, description='UART framing error flag. Read UARTxRX to clear.', accessibility='r', valueDescriptions=[(0b0, 'No framing error'), (0b1, 'Framing error on last reception')]))
r.AddBitField(BitField(name='UPEF', msb=4, description='UART parity error flag. Read UARTxRX to clear.', accessibility='r', valueDescriptions=[(0b0, 'No parity error'), (0b1, 'Parity error on last reception')]))
r.AddBitField(BitField(name='UOVF', msb=3, description='UART receive data overrun flag. Read UARTxRX to clear.', accessibility='r', valueDescriptions=[(0b0, 'No receive data overrun'), (0b1, 'Receive data overrun on last reception')]))
r.AddBitField(BitField(name='URCIF', msb=2, description='UART receive complete interrupt flag. Read UARTxRX to clear.', accessibility='r', valueDescriptions=[(0b0, 'No new receive complete interrupt pending'), (0b1, 'New receive complete interrupt pending')]))
r.AddBitField(BitField(name='UTEIF', msb=1, description='UART transmit register empty interrupt flag. Read UARTxSR to clear.', accessibility='r', valueDescriptions=[(0b0, 'No new transmit register empty interrupt pending'), (0b1, 'New transmit register empty interrupt pending')]))
r.AddBitField(BitField(name='UTCIF', msb=0, description='UART transmit complete interrupt flag. Read UARTxSR to clear.', accessibility='r', valueDescriptions=[(0b0, 'No new transmit complete interrupt pending'), (0b1, 'New transmit complete interrupt pending')]))

# UARTxBR
r = RegisterTemplate(nameTemplate='UARTxBR', registerMemorySlot=2, description='UART baud rate register', size=16)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=15, lsb=12, unused=True))
r.AddBitField(BitField(name='UBR', msb=11, lsb=0, description='UART baud rate = smclk / (16 * (UBR + 1))', accessibility='rw'))

# UARTxRX
r = RegisterTemplate(nameTemplate='UARTxRX', registerMemorySlot=3, description='UART receive buffer register', size=8)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='UARTxRX', msb=7, lsb=0, accessibility='r'))

# UARTxTX
r = RegisterTemplate(nameTemplate='UARTxTX', registerMemorySlot=4, description='UART transmit buffer register', size=8)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='UARTxTX', msb=7, lsb=0, accessibility='rw'))



''' TIMERx '''
p = PeripheralTemplate(nameTemplate='TIMERx', description='32-bit Timer/Counter with input capture, compare, and pulse-width modulation functionality')
m.AddPeripheralTemplate(p)

# TIMxCR
r = RegisterTemplate(nameTemplate='TIMxCR', registerMemorySlot=0, description='Timer/Counter control register', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=31, lsb=20, unused=True))
r.AddBitField(BitField(name='TIMDIV', msb=19, lsb=16, description='Timer/Counter clock divider. Divides the clock source selected by TIMSSEL to produce each increment to TIMxVAL', accessibility='rw', valueDescriptions=[(0, '/1 (no division)', '_1'), (1, '/2', '_2'), (2, '/4', '_4'), (3, '/8', '_8'), (4, '/16', '_16'), (5, '/32', '_32'), (6, '/64', '_64'), (7, '/128', '_128'), (8, '/256', '_256'), (9, '/512', '_512'), (10, '/1,024', '_1024'), (11, '/2,048', '_2048'), (12, '/4,096', '_4096'), (13, '/8,192', '_8192'), (14, '/16,384', '_16384'), (15, '/32,768', '_32768')]))
r.AddBitField(BitField(name='TIMCMP1IH', msb=15, description='Compare 1 TPCMP1 initial PWM logic state', accessibility='rw', valueDescriptions=[(0b0, 'Initial PWM logic state LOW'), (0b1, 'Initial PWM logic state HIGH')]))
r.AddBitField(BitField(name='TIMCMP0IH', msb=14, description='Compare 0 TPCMP0 initial PWM logic state', accessibility='rw', valueDescriptions=[(0b0, 'Initial PWM logic state LOW'), (0b1, 'Initial PWM logic state HIGH')]))
r.AddBitField(BitField(name='TIMCAP1FE', msb=13, description='Capture 1 edge select', accessibility='rw', valueDescriptions=[(0b0, 'Rising edge'), (0b1, 'Falling edge')]))
r.AddBitField(BitField(name='TIMCAP0FE', msb=12, description='Capture 0 edge select', accessibility='rw', valueDescriptions=[(0b0, 'Rising edge'), (0b1, 'Falling edge')]))
r.AddBitField(BitField(name='TIMCAP1EN', msb=11, description='Capture 1 enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='TIMCAP0EN', msb=10, description='Capture 0 enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='TIMSSEL', msb=9, lsb=8, description='Timer/Counter clock source select', accessibility='rw', valueDescriptions=[(0b00, 'SMCLK', '_SMCLK'), (0b01, 'MCLK', '_MCLK'), (0b10, 'Low frequency crystal clock', '_LFXT'), (0b11, 'High frequency crystal clock', '_HFXT')]))
r.AddBitField(BitField(name='TIMCMP2RST', msb=7, description='Enable Timer/Counter reset on Compare 2 event', accessibility='rw', valueDescriptions=[(0b0, 'Does not reset Timer/Counter on Compare 2 event'), (0b1, 'Resets Timer/Counter on Compare 2 event')]))
r.AddBitField(BitField(name='TIMEN', msb=6, description='Timer/Counter enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='TIMCAP1IE', msb=5, description='Capture 1 interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='TIMCAP0IE', msb=4, description='Capture 0 interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='TIMOVIE', msb=3, description='Timer/Counter overflow interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='TIMCMP2IE', msb=2, description='Compare 2 interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='TIMCMP1IE', msb=1, description='Compare 1 interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='TIMCMP0IE', msb=0, description='Compare 0 interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))

# TIMxSR
r = RegisterTemplate(nameTemplate='TIMxSR', registerMemorySlot=1, description='Timer/Counter status register. Write to register to clear bits 5 down to 0 regardless of what was written to the register', size=8)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='TCMP1', msb=7, description='Current value of the Compare 1 signal TPCMP1', accessibility='r', valueDescriptions=[(0b0, 'LOW'), (0b1, 'HIGH')]))
r.AddBitField(BitField(name='TCMP0', msb=6, description='Current value of the Compare 0 signal TPCMP0', accessibility='r', valueDescriptions=[(0b0, 'LOW'), (0b1, 'HIGH')]))
r.AddBitField(BitField(name='TIMCAP1IF', msb=5, description='Capture 1 interrupt flag', accessibility='rw0', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='TIMCAP0IF', msb=4, description='Capture 0 interrupt flag', accessibility='rw0', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='TIMOVIF', msb=3, description='Timer/Counter overflow interrupt flag', accessibility='rw0', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='TIMCMP2IF', msb=2, description='Compare 2 interrupt flag', accessibility='rw0', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='TIMCMP1IF', msb=1, description='Compare 1 interrupt flag', accessibility='rw0', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='TIMCMP0IF', msb=0, description='Compare 0 interrupt flag', accessibility='rw0', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))

# TIMxVAL
r = RegisterTemplate(nameTemplate='TIMxVAL', registerMemorySlot=2, description='Timer/Counter value register. Read to get the number of cycles of the divided down source clock since the timer was reset or enabled. Write to set an arbitrary starting point for the Timer/Counter.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='TIMxVAL', msb=31, lsb=0, accessibility='rw'))

# TIMxCMP0
r = RegisterTemplate(nameTemplate='TIMxCMP0', registerMemorySlot=3, description='Timer/Counter Compare 0 comparison register. When Compare 0 is enabled, a Compare 0 event will be triggered when TIMxVAL equals TIMxCMP0.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='TIMxCMP0', msb=31, lsb=0, accessibility='rw'))

# TIMxCMP1
r = RegisterTemplate(nameTemplate='TIMxCMP1', registerMemorySlot=4, description='Timer/Counter Compare 1 comparison register. When Compare 1 is enabled, a Compare 1 event will be triggered when TIMxVAL equals TIMxCMP1.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='TIMxCMP1', msb=31, lsb=0, accessibility='rw'))

# TIMxCMP2
r = RegisterTemplate(nameTemplate='TIMxCMP2', registerMemorySlot=5, description='Timer/Counter Compare 2 comparison register. When Compare 2 is enabled, a Compare 2 event will be triggered when TIMxVAL equals TIMxCMP2.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='TIMxCMP2', msb=31, lsb=0, accessibility='rw'))

# TIMxCAP0
r = RegisterTemplate(nameTemplate='TIMxCAP0', registerMemorySlot=6, description='Timer/Counter Capture 0 value register. When Capture 0 is enabled and a Capture 0 event occurs, this register will latch the value of TIMxVAL.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='TIMxCAP0', msb=31, lsb=0, accessibility='rw'))

# TIMxCAP1
r = RegisterTemplate(nameTemplate='TIMxCAP1', registerMemorySlot=7, description='Timer/Counter Capture 1 value register. When Capture 1 is enabled and a Capture 1 event occurs, this register will latch the value of TIMxVAL.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='TIMxCAP1', msb=31, lsb=0, accessibility='rw'))



''' I2Cx '''
p = PeripheralTemplate(nameTemplate='I2Cx', description='I2C serial port interface. The master and slave I2C interfaces are split between two sets of registers. Though it is possible to run the master and slave concurrently, doing so makes little sense, as they share the same I2C bus.')
m.AddPeripheralTemplate(p)

# I2CxMCR
r = RegisterTemplate(nameTemplate='I2CxMCR', registerMemorySlot=0, size=16, description='I2C master mode control register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=15, lsb=9, unused=True))
r.AddBitField(BitField(name='I2CIDL', msb=8, accessibility='rw', description='Forces bus state to idle', valueDescriptions=[(0b0, 'Do not force to idle'), (0b1, 'Force to idle')]))
r.AddBitField(BitField(name='I2CMEN', msb=7, accessibility='rw', description='I2C master mode enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CMRST', msb=6, accessibility='rw', description='I2C master mode reset', valueDescriptions=[(0b0, 'Not reset'), (0b1, 'Reset')]))
r.AddBitField(BitField(name='I2CMSPIE', msb=5, accessibility='rw', description='I2C master mode transmission stopped interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CMOVIE', msb=4, accessibility='rw', description='I2C master mode receive data overflow interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CMRCIE', msb=3, accessibility='rw', description='I2C master mode receive complete interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CMNIE', msb=2, accessibility='rw', description='I2C master mode NACK received interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CMTEIE', msb=1, accessibility='rw', description='I2C master mode I2CxMTX register empty interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CMTCIE', msb=0, accessibility='rw', description='I2C master mode transmit complete interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))

# I2CxMWC
r = RegisterTemplate(nameTemplate='I2CxMWC', registerMemorySlot=1, size=16, description='I2C master mode waveform control register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='I2CMHDIV', msb=15, lsb=8, accessibility='rw', description='I2C master mode high level clock divider'))
r.AddBitField(BitField(name='I2CMLDIV', msb=7, lsb=0, accessibility='rw', description='I2C master mode low level clock divider'))

# I2CxMTC
r = RegisterTemplate(nameTemplate='I2CxMTC', registerMemorySlot=2, size=16, description='I2C master mode transmit configuration register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='I2CMST', msb=15, accessibility='rw0', description='I2C master mode send start/restart with the data written to I2CxMTC (the slave address and the read/write mode)', valueDescriptions=[(0b0, 'Do nothing'), (0b1, 'Send start/restart, slave address, and read/write mode')]))
r.AddBitField(BitField(name='I2CMSAD', msb=14, lsb=8, accessibility='rw', description='I2C master mode 7-bit slave address of desired slave'))
r.AddBitField(BitField(name='I2CMR', msb=7, accessibility='rw', description='I2C master mode read mode', valueDescriptions=[(0b0, 'Write mode'), (0b1, 'Read mode')]))
r.AddBitField(BitField(name='I2CMNB', msb=6, lsb=0, accessibility='rw', description='I2C master mode number of bytes to receive. If set to 0, then an unlimited number of bytes will be received, and a stop condition must be manually generated.'))

# I2CxMSR
r = RegisterTemplate(nameTemplate='I2CxMSR', registerMemorySlot=3, size=16, description='I2C master mode status register. Read the register to clear all of its flags.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=15, lsb=9, unused=True))
r.AddBitField(BitField(name='I2CMARB', msb=8, accessibility='r', description='I2C master mode arbitration state', valueDescriptions=[(0b0, 'Normal'), (0b1, 'Arbitration lost')]))
r.AddBitField(BitField(name='I2CBS', msb=7, accessibility='r', description='I2C bus state', valueDescriptions=[(0b0, 'Inactive'), (0b1, 'Active')]))
r.AddBitField(BitField(name='I2CMBUSY', msb=6, accessibility='r', description='I2C master mode busy (transmitting or receiving)', valueDescriptions=[(0b0, 'Not busy'), (0b1, 'Busy')]))
r.AddBitField(BitField(name='I2CMSPIF', msb=5, accessibility='r', description='I2C master mode transmission stopped interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CMOVIF', msb=4, accessibility='r', description='I2C master mode receive data overflow interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CMRCIF', msb=3, accessibility='r', description='I2C master mode receive complete interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CMNIF', msb=2, accessibility='r', description='I2C master mode NACK received interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CMTEIF', msb=1, accessibility='r', description='I2C master mode I2CxMTX register empty interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CMTCIF', msb=0, accessibility='r', description='I2C master mode transmit complete interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))

# I2CxMTX
r = RegisterTemplate(nameTemplate='I2CxMTX', registerMemorySlot=4, size=8, description='I2C master mode transmit register. Write to this register to send the written data over the I2C bus. Also sends a start condition before the data is sent if no transfer is currently ongoing.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='I2CxMTX', msb=7, lsb=0, accessibility='rw'))

# I2CxMTXST
r = RegisterTemplate(nameTemplate='I2CxMTXST', registerMemorySlot=5, size=8, description='I2C master mode transmit register with start/restart condition. Write to this register to send a start/restart condition and then send the written data over the I2C bus.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='I2CxMTXST', msb=7, lsb=0, accessibility='rw'))

# I2CxMTXSP
r = RegisterTemplate(nameTemplate='I2CxMTXSP', registerMemorySlot=6, size=8, description='I2C master mode transmit register with stop condition. Write to this register to send the written data and then send a stop condition over the I2C bus.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='I2CxMTXSP', msb=7, lsb=0, accessibility='rw'))

# I2CxMRX
r = RegisterTemplate(nameTemplate='I2CxMRX', registerMemorySlot=7, size=8, description='I2C master mode receive register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='I2CxMRX', msb=7, lsb=0, accessibility='r'))

# I2CxSCR
r = RegisterTemplate(nameTemplate='I2CxSCR', registerMemorySlot=8, size=16, description='I2C slave mode control register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=15, unused=True))
r.AddBitField(BitField(name='I2CSSAD', msb=14, lsb=8, accessibility='rw', description='I2C slave mode slave address (self address)'))
r.AddBitField(BitField(name='I2CSEN', msb=7, accessibility='rw', description='I2C slave mode enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CSRST', msb=6, accessibility='rw', description='I2C slave mode reset', valueDescriptions=[(0b0, 'Not reset'), (0b1, 'Reset')]))
r.AddBitField(BitField(name='I2CSSPIE', msb=5, accessibility='rw', description='I2C slave mode stop condition received interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CSOVIE', msb=4, accessibility='rw', description='I2C slave mode receive data overflow interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CSRCIE', msb=3, accessibility='rw', description='I2C slave mode receive complete interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CSNIE', msb=2, accessibility='rw', description='I2C slave mode NACK received interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CSTEIE', msb=1, accessibility='rw', description='I2C slave mode I2CxMTX register empty interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='I2CSTCIE', msb=0, accessibility='rw', description='I2C slave mode transmit complete interrupt enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))

# I2CxSSR
r = RegisterTemplate(nameTemplate='I2CxSSR', registerMemorySlot=9, size=8, description='I2C slave mode status register. Read the register to clear all of its flags.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='I2CSBS', msb=7, accessibility='r', description='I2C bus state (equivalent to I2CBS in I2CxMSR)', valueDescriptions=[(0b0, 'Inactive'), (0b1, 'Active')]))
r.AddBitField(BitField(name='I2CSBUSY', msb=6, accessibility='r', description='I2C slave mode busy (transmitting or receiving)', valueDescriptions=[(0b0, 'Not busy'), (0b1, 'Busy')]))
r.AddBitField(BitField(name='I2CSSPIF', msb=5, accessibility='r', description='I2C slave mode stop condition received interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CSOVIF', msb=4, accessibility='r', description='I2C slave mode receive data overflow interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CSRCIF', msb=3, accessibility='r', description='I2C slave mode receive complete interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CSNIF', msb=2, accessibility='r', description='I2C slave mode NACK received interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CSTEIF', msb=1, accessibility='r', description='I2C slave mode I2CxMTX register empty interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='I2CSTCIF', msb=0, accessibility='r', description='I2C slave mode transmit complete interrupt flag', valueDescriptions=[(0b0, 'No pending interrupt'), (0b1, 'Interrupt pending')]))

# I2CxSTX
r = RegisterTemplate(nameTemplate='I2CxSTX', registerMemorySlot=10, size=8, description='I2C slave mode transmit register. Write to this register to transmit the written data over the I2C bus.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='I2CxSTX', msb=7, lsb=0, accessibility='rw'))

# I2CxSRX
r = RegisterTemplate(nameTemplate='I2CxSRX', registerMemorySlot=11, size=8, description='I2C slave mode receive register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='I2CxSRX', msb=7, lsb=0, accessibility='r'))



''' NNx '''
p = PeripheralTemplate(nameTemplate='NNx', description='Fixed point artificial neural network hardware accelerator. The peripheral calculates a single layer of a multilayer perceptron neural network. The input is a vector of signed Q0.15 integers (signed int16), and the output is a vector of signed Q0.15 integers (signed int16), and the weights are 24-bit signed Q8.15 numbers (signed int24). It can be configured to use a linear activation function or a logistic sigmoid approximation activation function. The input vector, output vector, and weights must all fit inside a single 16 KiB dual-port SRAM.')
m.AddPeripheralTemplate(p)

# NNxCR
r = RegisterTemplate(nameTemplate='NNxCR', registerMemorySlot=0, description='Neural network control register', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=31, lsb=23, unused=True))
r.AddBitField(BitField(name='NNCIE', msb=22, description='Neural network layer complete interrupt enable', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='NNCIF', msb=21, description='Neural network layer complete interrupt flag. Write a 0 to clear the flag.', accessibility='rw0', valueDescriptions=[(0b0, 'No interrupt pending'), (0b1, 'Interrupt pending')]))
r.AddBitField(BitField(name='NNLSIS', msb=20, description='Logistic sigmoid input select. Used for testing the hardware logistic sigmoid approximation activation function.', accessibility='rw', valueDescriptions=[(0b0, 'Internal input (required for neural network usage)'), (0b1, 'Input is NNxLSI (used for testing)')]))
r.AddBitField(BitField(name='NNCS', msb=19, description='Neural network clock select', accessibility='rw', valueDescriptions=[(0b0, 'smclk'), (0b1, 'mclk')]))
r.AddBitField(BitField(name='NNBIAS', msb=18, description='Neural network layer bias enable, used to insert a bias from the synaptic weights into the input of the activation function', accessibility='rw', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='NNAFS', msb=17, description='Activation function select', accessibility='rw', valueDescriptions=[(0b0, 'Logistic sigmoid approximation'), (0b1, 'Linear')]))
r.AddBitField(BitField(name='NNRUN', msb=16, description='Neural network run. Set to start the neural network accelerator process. Read to determine if the neural network accelerator is running or not.', accessibility='rw1', valueDescriptions=[(0b0, 'Not running'), (0b1, 'Running (write 1 to start)')]))
r.AddBitField(BitField(name='NNO', msb=15, lsb=8, description='Number of neural network outputs in output vector minus 1. The actual number of outputs is NNO + 1', accessibility='rw'))
r.AddBitField(BitField(name='NNI', msb=7, lsb=0, description='Number of neural network inputs in input vector minus 1. The actual number of inputs is NNI + 1.', accessibility='rw'))

# NNxIVA
r = RegisterTemplate(nameTemplate='NNxIVA', registerMemorySlot=1, description='Input vector start address. Must be contained within the appropriate dual-port SRAM, and must be on a 4-byte boundary. Each input in the input vector is a signed int16 (signed Q0.15) number. Inputs in the input vector must be stored as follows. The input at index 0 must be stored with its LSbyte at NNxIVA + 0 (in bytes) and its MSbyte at NNxIVA + 1 (in bytes). The input at index 1 must be stored with its LSbyte at NNxIVA + 2 (in bytes) and its MSbyte at NNxIVA + 3 (in bytes). The rest of the inputs follow the same sequence.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=31, lsb=14, unused=True))
r.AddBitField(BitField(name='NNIVA', msb=13, lsb=2, description='Input vector start address (divided by 4)', accessibility='rw'))
r.AddBitField(BitField(msb=1, lsb=0, unused=True))

# NNxOVA
r = RegisterTemplate(nameTemplate='NNxOVA', registerMemorySlot=2, description='Output vector start address. Must be contained within the appropriate dual-port SRAM, and must be on a 4-byte boundary. Each output in the output vector is a signed int16 (signed Q0.15) number. Outputs in the output vector are stored as follows. The output at index 0 is stored with its LSbyte at NNxOVA + 0 (in bytes) and its MSbyte at NNxOVA + 1 (in bytes). The output at index 1 is stored with its LSbyte at NNxOVA + 2 (in bytes) and its MSbyte at NNxOVA + 3 (in bytes). The rest of the outputs follow the same sequence.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=31, lsb=14, unused=True))
r.AddBitField(BitField(name='NNOVA', msb=13, lsb=2, description='Output vector start address (divided by 4)', accessibility='rw'))
r.AddBitField(BitField(msb=1, lsb=0, unused=True))

# NNxWMA
r = RegisterTemplate(nameTemplate='NNxWMA', registerMemorySlot=3, description='Synaptic weights matrix start address. Must be contained within the appropriate dual-port SRAM, and must be on a 4-byte boundary. Each synaptic weight in the synaptic weights matrix is a signed int24 (signed Q8.15) number. Note that bit 23 of each weight is the sign bit. Weights in the weights matrix are stored as follows. The weight at index 0 is stored with its LSbyte at NNxWMA + 0 (in bytes), its center byte at NNxWMA + 1 (in bytes), and its MSbyte at NNxWMA + 2 (in bytes). The weight at index 1 is stored with its LSbyte at NNxWMA + 3 (in bytes), its center byte at NNxWMA + 4 (in bytes), and its MSbyte at NNxWMA + 5 (in bytes). The weight at index 2 is stored with its LSbyte at NNxWMA + 6 (in bytes), its center byte at NNxWMA + 7 (in bytes), and its MSbyte at NNxWMA + 8 (in bytes). The weight at index 3 is stored with its LSbyte at NNxWMA + 9 (in bytes), its center byte at NNxWMA + 10 (in bytes), and its MSbyte at NNxWMA + 11 (in bytes). The rest of the weights follow the same sequence.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=31, lsb=14, unused=True))
r.AddBitField(BitField(name='NNWMA', msb=13, lsb=2, description='Synaptic weights matrix start address (divided by 4)', accessibility='rw'))
r.AddBitField(BitField(msb=1, lsb=0, unused=True))

# NNxLSI
r = RegisterTemplate(nameTemplate='NNxLSI', registerMemorySlot=4, description='Logistic sigmoid input, which is a signed int32 (signed Q8.15) number. Used for testing the hardware logistic sigmoid approximation activation function. When NNLSIS is set, NNxLSO will contain the output of the hardware logistic sigmoid approximation with NNxLSI as its input.', size=32)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='NNxLSI', msb=31, lsb=0, accessibility='rw'))

# NNxLSO
r = RegisterTemplate(nameTemplate='NNxLSO', registerMemorySlot=5, description='Logistic sigmoid output, which is a signed int16 (signed Q0.15) number. Used for testing the hardware logistic sigmoid approximation activation function. When NNLSIS is set, NNxLSO will contain the output of the hardware logistic sigmoid approximation with NNxLSI as its input.', size=16)
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='NNxLSO', msb=15, lsb=0, accessibility='rw'))



''' Pulse Counter '''
p = PeripheralTemplate(nameTemplate='PC', description='Pulse counter. Counts the number of digital pulses generated by a sensor, such as a Domino Neutron detector or a Geiger-Muller tube.')
m.AddPeripheralTemplate(p)

# PCCR
r = RegisterTemplate(nameTemplate='PCCR', registerMemorySlot=0, size=16, description='Pulse counter control register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(msb=15, lsb=12, unused=True))
r.AddBitField(BitField(name='ENPC0', msb=0, accessibility='rw', description='Enables pulse counter 0', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='ENPC1', msb=1, accessibility='rw', description='Enables pulse counter 1', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='ENPC2', msb=2, accessibility='rw', description='Enables pulse counter 2', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='ENPC3', msb=3, accessibility='rw', description='Enables pulse counter 3', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='RSTPC0', msb=4, accessibility='rw', description='Reset pulse counter 0', valueDescriptions=[(0b0, 'Not reset'), (0b1, 'Reset')]))
r.AddBitField(BitField(name='RSTPC1', msb=5, accessibility='rw', description='Reset pulse counter 1', valueDescriptions=[(0b0, 'Not reset'), (0b1, 'Reset')]))
r.AddBitField(BitField(name='RSTPC2', msb=6, accessibility='rw', description='Reset pulse counter 2', valueDescriptions=[(0b0, 'Not reset'), (0b1, 'Reset')]))
r.AddBitField(BitField(name='RSTPC3', msb=7, accessibility='rw', description='Reset pulse counter 3', valueDescriptions=[(0b0, 'Not reset'), (0b1, 'Reset')]))
r.AddBitField(BitField(name='ESPC0', msb=8, accessibility='rw', description='Edge select for pulse counter 0', valueDescriptions=[(0b0, 'Rising edge'), (0b1, 'Falling edge')]))
r.AddBitField(BitField(name='ESPC1', msb=9, accessibility='rw', description='Edge select for pulse counter 1', valueDescriptions=[(0b0, 'Rising edge'), (0b1, 'Falling edge')]))
r.AddBitField(BitField(name='ESPC2', msb=10, accessibility='rw', description='Edge select for pulse counter 2', valueDescriptions=[(0b0, 'Rising edge'), (0b1, 'Falling edge')]))
r.AddBitField(BitField(name='ESPC3', msb=11, accessibility='rw', description='Edge select for pulse counter 3', valueDescriptions=[(0b0, 'Rising edge'), (0b1, 'Falling edge')]))


# PCCNT0
r = RegisterTemplate(nameTemplate='PCCNT0', registerMemorySlot=1, size=32, description='Pulse counter 0 count register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PCCNT0', msb=31, lsb=0, accessibility='r'))

# PCCNT1
r = RegisterTemplate(nameTemplate='PCCNT1', registerMemorySlot=2, size=32, description='Pulse counter 1 count register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PCCNT1', msb=31, lsb=0, accessibility='r'))

# PCCNT2
r = RegisterTemplate(nameTemplate='PCCNT2', registerMemorySlot=3, size=32, description='Pulse counter 2 count register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PCCNT2', msb=31, lsb=0, accessibility='r'))

# PCCNT3
r = RegisterTemplate(nameTemplate='PCCNT3', registerMemorySlot=4, size=32, description='Pulse counter 3 count register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='PCCNT3', msb=31, lsb=0, accessibility='r'))



''' AFEx '''
p = PeripheralTemplate(nameTemplate='AFEx', description='Analog front-end interface. Capable of pulse height analysis (PHA) and pulse shape discrimination (PSD). Features a DMA to place PHA and PSD data directly into RAM without CPU intervention.')
m.AddPeripheralTemplate(p)

# AFExCR0
r = RegisterTemplate(nameTemplate='AFExCR0', registerMemorySlot=0, size=32, description='AFE control register 0')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AfeAdcClkDiv', msb=2, lsb=0, accessibility='rw', description='Adjusts the division factor of the ADC clock', valueDescriptions=[(0b000, '/1 (no division)', '_1'), (0b001, '/2 ', '_2'), (0b010, '/4', '_4'), (0b011, '/8', '_8'), (0b100, '/16', '_16'), (0b101, '/32', '_32'), (0b110, '/64', '_64'), (0b111, '/128', '_128')]))
r.AddBitField(BitField(name='AfeAdcCp', msb=9, lsb=3, accessibility='rw', description='ADC pole capacitor adjustment. This sets the minimum and maximum convertible voltage for the ADC, centered around VDD/2. Each increment is 31.32 fF, beginning at 0 fF for a value of 0. Though a value of 2.5 pF is ideal, you should set this value to around 2.2 pF to account for parasitics.'))
r.AddBitField(BitField(name='AfeAdcMuxTest', msb=10, accessibility='rw', description='Sets the ADC MUX to test mode, which allows the ADC to be tested with an external voltage. When activated, the positive input of the ADC will be connected to InPmtx, and the negative input to ATPx.', valueDescriptions=[(0b0, 'Normal operation'), (0b1, 'ADC MUX test mode')]))
r.AddBitField(BitField(name='AfeAtpBufEn', msb=11, accessibility='rw', description='Analog test port buffer enable. When disabled, the analog test port will output the raw analog signal, which may be susceptible to external noise and loading. When enabled, an internal buffer will engage to provide a level of shielding to the internal analog signal, at the cost of added noise, potentially reduced bandwidth, and slew rate limitations.', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='AfeAtpSel', msb=15, lsb=12, accessibility='rw', description='Selects the internal analog front-end signal that connects to the analog test port', valueDescriptions=[(0b0000, 'Analog ground', '_VSS25'), (0b0001, 'PMT input', '_InPmt'), (0b0010, 'CSA input', '_CsaIn'), (0b0011, 'CSA output', '_CsaOut'), (0b0100, 'Pulse height analysis positive sample and hold output to ADC', '_PHA_P'), (0b0101, 'Pulse shape discrimination early window positive sample and hold output to ADC', '_PsdEarly_P'), (0b0110, 'Pulse shape discrimination late window positive sample and hold output to ADC', '_PsdLate_P'), (0b0111, 'Pulse height analysis negative sample and hold output to ADC', '_PHA_M'), (0b1000, 'Current mirror mid voltage. This is the PMT current converted to a voltage inside the current mirrors.', '_MidCM'), (0b1001, 'The sampled input to the current mirrors', '_InSampled'), (0b1010, 'Current mirror sample and hold reference voltage', '_VCMSHRef'), (0b1011, 'Peak sample and hold reference voltage', '_VPeakSHRef'), (0b1100, 'Voltage supply for CSA bias DACs', '_VddDacCsa'), (0b1101, 'Voltage supply for miscellaneous DACs', '_VddDacMisc'), (0b1110, 'High current CSA bias P cascode voltage', '_VCHCBPC'), (0b1111, 'Current mirror output. When unbuffered, you can use this port to sense the current coming from the current mirrors.', '_CMOut')]))
r.AddBitField(BitField(name='AfeClkSel', msb=17, lsb=16, accessibility='rw', description='Selects the source clock for the analog front-end finite state machine', valueDescriptions=[(0b00, 'Main clock', '_MCLK'), (0b01, 'Submain clock', '_SMCLK'), (0b10, 'High frequency crystal oscillator clock', '_HFXT'), (0b11, 'Digitally controlled oscillator 0 clock', '_DCO0')]))
r.AddBitField(BitField(name='AfeCMCCB', msb=18, accessibility='rw', description='Current mirror coupling capacitor bypass', valueDescriptions=[(0b0, 'Not bypassed (enabled)'), (0b1, 'Bypassed (shorted)')]))
r.AddBitField(BitField(name='AfeCMOutEn', msb=19, accessibility='rw', description='Current mirror output enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='AfeCMSHClkDiv', msb=23, lsb=20, accessibility='rw', description='Current mirror sample and hold clock divider. Frequency = analog front-end clock frequency / 2**AfeCMSHClkDiv'))
r.AddBitField(BitField(name='AfeCS', msb=29, lsb=24, accessibility='rw', description='Current sink value. The current sink allows an adjustable amount of current to be diverted away from going into the input of the CSA to account for offsets created by the current mirrors. A zero value of CS sinks 0 A of current.'))
r.AddBitField(BitField(msb=31, lsb=30, unused=True))

# AFExCR1
r = RegisterTemplate(nameTemplate='AFExCR1', registerMemorySlot=1, size=32, description='AFE control register 1')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AfeCHCCmAdj', msb=2, lsb=0, accessibility='rw', description='High current CSA Miller capacitor ajustment. This is used to stabilize the CSA and prevent overshoots by reducing its pole frequency and bandwidth. Increments by 100 fF. A zero value is 0 fF (an open circuit).'))
r.AddBitField(BitField(name='AfeCsaForceRst', msb=3, accessibility='rw', description='Force the CSA into reset', valueDescriptions=[(0b0, 'Normal operation'), (0b1, 'Force CSA reset (short CSA input to output)')]))
r.AddBitField(BitField(name='AfeCsaForceUnRst', msb=4, accessibility='rw', description='Prevent the CSA from being reset by the analog front-end finite state machine', valueDescriptions=[(0b0, 'Normal operation'), (0b1, 'Not reset')]))
r.AddBitField(BitField(name='AfeCsaRstMode', msb=5, accessibility='rw', description='The CSA reset mode. Controls when the CSA is reset.', valueDescriptions=[(0b0, 'The CSA is reset only while the CSA reset timer is running'), (0b1, 'The CSA is reset while the CSA reset timer is running and continues being reset until the next pulse is detected by the threshold comparator')]))
r.AddBitField(BitField(name='AfeCsaSel', msb=6, accessibility='rw', description='Selects which CSA to use', valueDescriptions=[(0b0, 'High current CSA'), (0b1, 'Low current CSA')]))
r.AddBitField(BitField(name='AfeDoPhaLast', msb=7, accessibility='rw', description='Determines the ordering of the PHA and late PSD sampling', valueDescriptions=[(0b0, 'PHA is sampled before late PSD'), (0b1, 'Late PSD is sampled before PHA')]))
r.AddBitField(BitField(name='AfeDTP0Sel', msb=12, lsb=8, accessibility='rw', description='Digital test port 0 select', valueDescriptions=[(0b0000, 'AdcActive', '_AdcActive'), (0b0001, 'AdcCmpBar', '_AdcCmpBar'), (0b0010, 'AdcDataReady', '_AdcDataReady'), (0b0011, 'AdcSampling', '_AdcSampling'), (0b0100, 'ClkAdc', '_ClkAdc'), (0b0101, 'ClkAdcValue', '_ClkAdcValue'), (0b0110, 'ClkFsm', '_ClkFsm'), (0b0111, 'CMSHSel', '_CMSHSel'), (0b1000, 'CMSHTrack(0)', '_CMSHTrack0'), (0b1001, 'CMSHTrack(1)', '_CMSHTrack1'), (0b1010, 'ConvPha', '_ConvPha'), (0b1011, 'ConvPsdE', '_ConvPsdE'), (0b1100, 'ConvPsdL', '_ConvPsdL'), (0b1101, 'CsaDip', '_CsaDip'), (0b1110, 'CsaReset', '_CsaReset'), (0b1111, 'EnPhaSH', '_EnPhaSH'), (0b10000, 'EnPsdSH', '_EnPsdSH'), (0b10001, 'ForceTrigger', '_ForceTrigger'), (0b10010, 'ForceTriggerDelay', '_ForceTriggerDelay'), (0b10011, 'FsmTimerDone', '_FsmTimerDone'), (0b10100, 'IntPha', '_IntPha'), (0b10101, 'IntPsdE', '_IntPsdE'), (0b10110, 'IntPsdL', '_IntPsdL'), (0b10111, 'NewPulseDelay', '_NewPulseDelay'), (0b11000, 'NewForceTrigger', '_NewForceTrigger'), (0b11001, 'PhaTrack', '_PhaTrack'), (0b11010, 'PsdEarlyTrack', '_PsdEarlyTrack'), (0b11011, 'PsdLateTrack', '_PsdLateTrack'), (0b11100, 'Rejecting', '_Rejecting'), (0b11101, 'RejectTimerReset', '_RejectTimerReset'), (0b11110, 'ThreshCmp', '_ThreshCmp'), (0b11111, 'ThreshCmpStretch', '_ThreshCmpStretch')]))
r.AddBitField(BitField(name='AfeDTP1Sel', msb=17, lsb=13, accessibility='rw', description='Digital test port 1 select', valueDescriptions=[(0b0000, 'AdcActive', '_AdcActive'), (0b0001, 'AdcCmpBar', '_AdcCmpBar'), (0b0010, 'AdcDataReady', '_AdcDataReady'), (0b0011, 'AdcSampling', '_AdcSampling'), (0b0100, 'ClkAdc', '_ClkAdc'), (0b0101, 'ClkAdcValue', '_ClkAdcValue'), (0b0110, 'ClkFsm', '_ClkFsm'), (0b0111, 'CMSHSel', '_CMSHSel'), (0b1000, 'CMSHTrack(0)', '_CMSHTrack0'), (0b1001, 'CMSHTrack(1)', '_CMSHTrack1'), (0b1010, 'ConvPha', '_ConvPha'), (0b1011, 'ConvPsdE', '_ConvPsdE'), (0b1100, 'ConvPsdL', '_ConvPsdL'), (0b1101, 'CsaDip', '_CsaDip'), (0b1110, 'CsaReset', '_CsaReset'), (0b1111, 'EnPhaSH', '_EnPhaSH'), (0b10000, 'EnPsdSH', '_EnPsdSH'), (0b10001, 'ForceTrigger', '_ForceTrigger'), (0b10010, 'ForceTriggerDelay', '_ForceTriggerDelay'), (0b10011, 'FsmTimerDone', '_FsmTimerDone'), (0b10100, 'IntPha', '_IntPha'), (0b10101, 'IntPsdE', '_IntPsdE'), (0b10110, 'IntPsdL', '_IntPsdL'), (0b10111, 'NewPulseDelay', '_NewPulseDelay'), (0b11000, 'NewForceTrigger', '_NewForceTrigger'), (0b11001, 'PhaTrack', '_PhaTrack'), (0b11010, 'PsdEarlyTrack', '_PsdEarlyTrack'), (0b11011, 'PsdLateTrack', '_PsdLateTrack'), (0b11100, 'Rejecting', '_Rejecting'), (0b11101, 'RejectTimerReset', '_RejectTimerReset'), (0b11110, 'ThreshCmp', '_ThreshCmp'), (0b11111, 'ThreshCmpStretch', '_ThreshCmpStretch')]))
r.AddBitField(BitField(name='AfeEn', msb=18, accessibility='rw', description='Analog front-end master enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='AfeEnCM', msb=19, accessibility='rw', description='Current mirror enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='AfeEnCsaDip', msb=20, accessibility='rw', description='CSA dip reset enable. If enabled, the CSA will reset if its output drops below the dip threshold voltage.', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='AfeEnDma', msb=21, accessibility='rw', description='Analog front-end DMA enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='AfeEnPsd', msb=22, accessibility='rw', description='PSD enable. When enabled, the analog front-end finite state machine will perform pulse height analysis and pulse shape discrimination. When disabled, it only performs pulse height analysis', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))
r.AddBitField(BitField(name='AfeForcePhaTrack', msb=23, accessibility='rw', description='Forces the pulse height analysis sample and hold into track mode', valueDescriptions=[(0b0, 'Normal operation'), (0b1, 'Force into track mode')]))
r.AddBitField(BitField(name='AfeForceTrigger', msb=24, accessibility='rw', description='Forces the analog front-end to begin processing as if the pulse threshold comparator had indicated that a new pulse had arrived. This only occurs once every time this bit is changed from a 0 to a 1.', valueDescriptions=[(0b0, 'Normal operation'), (0b1, 'Force a trigger')]))
r.AddBitField(BitField(name='AfePsdFullIE', msb=25, accessibility='rw', description='Triggers an interrupt when the PSD memory is full', valueDescriptions=[(0b0, 'Interrupt disabled'), (0b1, 'Interrupt enabled')]))
r.AddBitField(BitField(name='AfeRejectMode', msb=26, accessibility='rw', description='Determines the pulse reject mode', valueDescriptions=[(0b0, 'Reject timer begins counting when a new pulse is first detected and starts over only if another new pulse occurs before the first reject time elapses'), (0b1, 'Reject timer begins after a pulse is no longer detected and resets whenever a pulse is detected')]))
r.AddBitField(BitField(name='AfeRstPulseCounts', msb=27, accessibility='rw', description='Resets the AFExVPC and AFExTPC registers', valueDescriptions=[(0b0, 'Does nothing'), (0b1, 'Resets the counts registers')]))
r.AddBitField(BitField(name='AfeSHPwrEvent', msb=28, accessibility='rw', description='Controls the event-driven power down status of the peak sample and hold circuits', valueDescriptions=[(0b0, 'Sample and hold circuits are always powered on'), (0b1, 'Sample and hold circuits are only powered on during an event')]))
r.AddBitField(BitField(name='AfeThreshSel', msb=29, accessibility='rw', description='Selects which signal to use to detect new pulses with the threshold comparator', valueDescriptions=[(0b0, 'The CSA output is used to detect new pulses'), (0b1, 'The current mirror mid voltage is used to detect new pulses')]))
r.AddBitField(BitField(msb=31, lsb=30, unused=True))

# AFExSR
r = RegisterTemplate(nameTemplate='AFExSR', registerMemorySlot=2, size=8, description='AFE status register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AfeAdcActive', msb=0, accessibility='r', description='Indicates that the ADC is currently active either sampling or converting', valueDescriptions=[(0b0, 'ADC inactive'), (0b1, 'ADC active')]))
r.AddBitField(BitField(name='AfeAdcValueType', msb=2, lsb=1, accessibility='r', description='Indicates what type of data the converted value from the ADC represents. Note that this value is only valid for 1 cycle of the AFE clock after the falling edge of AdcDataReady.', valueDescriptions=[(0b00, 'Forced value (generated by AfeForceTrigger', '_Forced'), (0b01, 'Early PSD value', '_EarlyPSD'), (0b10, 'PHA value', '_PHA'), (0b11, 'Late PSD value', '_LatePSD')]))
r.AddBitField(BitField(name='AfeDTP0', msb=3, accessibility='r', description='The current value of digital test port 0'))
r.AddBitField(BitField(name='AfeDTP1', msb=4, accessibility='r', description='The current value of digital test port 1'))
r.AddBitField(BitField(name='AfePsdFull', msb=5, accessibility='rw1', description='PSD memory full interrupt flag. Write anything to this register to clear the flag and allow the analog front end finite state machine to overwrite the memory with new pulse data.'))
r.AddBitField(BitField(msb=7, lsb=6, unused=True))

# AFExADC
r = RegisterTemplate(nameTemplate='AFExADC', registerMemorySlot=3, size=16, description='ADC data register. Shows the value of the most recent ADC conversion.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExADC', msb=9, lsb=0, accessibility='r'))
r.AddBitField(BitField(msb=15, lsb=10, unused=True))

# AFExPIT
r = RegisterTemplate(nameTemplate='AFExPIT', registerMemorySlot=4, size=16, description='PHA integration time register. When this timer elapses, the PHA peak sample and hold latches the output of the CSA and allows the ADC to begin converting it. If AfeEnPsd is 0, the timer starts immediately after a valid new pulse is detected. If AfeEnPsd is 1 and AfeDoPhaLast is 0, the timer starts after the early PSD integration timer elapses. If AfeEnPsd is 1 AfeDoPhaLast 1, it starts after the late PSD integration timer elapses.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExPIT', msb=15, lsb=0, accessibility='rw'))

# AFExEIT
r = RegisterTemplate(nameTemplate='AFExEIT', registerMemorySlot=5, size=16, description='PSD early integration time register. When this timer elapses, the early PSD peak sample and hold latches the output of the CSA and allows the ADC to begin converting it. If AfeEnPsd is 0, the timer is disabled. If 1, the timer starts immediately after a valid new pulse is detected.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExEIT', msb=15, lsb=0, accessibility='rw'))

# AFExLIT
r = RegisterTemplate(nameTemplate='AFExLIT', registerMemorySlot=6, size=16, description='PSD late integration time register. When this timer elapses, the late PSD peak sample and hold latches the output of the CSA and allows the ADC to begin converting it. If AfeEnPsd is 0, the timer is disabled. If AfeEnPsd is 1 and AfeDoPhaLast is 1, the timer starts after the early PSD integration timer elapses. If AfeEnPsd is 1 and AfeDoPhaLast is 0, it starts after the PHA integration timer elapses.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExLIT', msb=15, lsb=0, accessibility='rw'))

# AFExRT
r = RegisterTemplate(nameTemplate='AFExRT', registerMemorySlot=7, size=16, description='Reject time register. After a pulse is detected by the AFE, any subsequent pulse that is detected within the reject time will be rejected. See AfeRejectMode to determine when the reject timer is reset.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExRT', msb=15, lsb=0, accessibility='rw'))

# AFExCRT
r = RegisterTemplate(nameTemplate='AFExCRT', registerMemorySlot=8, size=8, description='CSA reset time register. Determines the amount of time the CSA is held in reset after the reject timer has elapsed.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCRT', msb=7, lsb=0, accessibility='rw'))

# AFExCFB
r = RegisterTemplate(nameTemplate='AFExCFB', registerMemorySlot=9, size=8, description='CSA feedback capacitance register. Increment is 250 fF, except for bit 7, which adds 20 pF. A value of 0 gives 250 fF.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCFB', msb=7, lsb=0, accessibility='rw'))

# AFExCMCC
r = RegisterTemplate(nameTemplate='AFExCMCC', registerMemorySlot=10, size=8, description='Current mirror coupling capacitance register.  Increment is 250 fF, except for bit 7, which adds 20 pF. A value of 0 gives 81 pF.')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCMCC', msb=7, lsb=0, accessibility='rw'))

# AFExBRST
r = RegisterTemplate(nameTemplate='AFExBRST', registerMemorySlot=11, size=16, description='Baseline reset register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AfeBaselineRstV', msb=13, lsb=0, accessibility='rw', description='The baseline reset DAC value. When baseline reset mode is enabled, the InPmt pin voltage is set to the baseline reset DAC voltage.'))
r.AddBitField(BitField(name='AfeBaselineRstInv', msb=14, accessibility='rw', description='Inverts the polarity of the BASERSTx pin', valueDescriptions=[(0b0, 'BASERSTx is active high'), (0b1, 'BASERSTx is active low')]))
r.AddBitField(BitField(name='AfeEnBaselineRst', msb=15, accessibility='rw', description='Baseline reset enable', valueDescriptions=[(0b0, 'Disabled'), (0b1, 'Enabled')]))

# AFExAREF
r = RegisterTemplate(nameTemplate='AFExAREF', registerMemorySlot=12, size=16, description='ADC reference DAC register. Centers the CSA swing on the common mode voltage of the ADC, which is AVDD/2, by setting the ADC reference voltage Vref. The ADC buffer converts the differential inputs VInP and VInM to a single-ended signal referenced to VSS with the equation Vbuf = (VInP - VInM) + Vref')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExAREF', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))


# AFExCMSHR
r = RegisterTemplate(nameTemplate='AFExCMSHR', registerMemorySlot=13, size=16, description='Current mirror sample and hold reference DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCMSHR', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExCDT
r = RegisterTemplate(nameTemplate='AFExCDT', registerMemorySlot=14, size=16, description='CSA dip threshold DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCDT', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExCHCR
r = RegisterTemplate(nameTemplate='AFExCHCR', registerMemorySlot=15, size=16, description='High current CSA reference DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCHCR', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExPSHR
r = RegisterTemplate(nameTemplate='AFExPSHR', registerMemorySlot=16, size=16, description='Peak sample and hold reference DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExPSHR', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExRFB
r = RegisterTemplate(nameTemplate='AFExRFB', registerMemorySlot=17, size=16, description='CSA feedback resistance DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExRFB', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExTHR
r = RegisterTemplate(nameTemplate='AFExTHR', registerMemorySlot=18, size=16, description='Threshold DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExTHR', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExCHCBP
r = RegisterTemplate(nameTemplate='AFExCHCBP', registerMemorySlot=19, size=16, description='High current CSA bias P DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCHCBP', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExCHCBPC
r = RegisterTemplate(nameTemplate='AFExCHCBPC', registerMemorySlot=20, size=16, description='High current CSA bias P cascode DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCHCBPC', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExCHCBNC
r = RegisterTemplate(nameTemplate='AFExCHCBNC', registerMemorySlot=21, size=16, description='High current CSA bias N cascode DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCHCBNC', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExCHCBN
r = RegisterTemplate(nameTemplate='AFExCHCBN', registerMemorySlot=22, size=16, description='High current CSA bias N DAC register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExCHCBN', msb=13, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=15, lsb=14, unused=True))

# AFExCLC0
r = RegisterTemplate(nameTemplate='AFExCLC0', registerMemorySlot=23, size=32, description='Low current CSA bias register 0')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AfeCLCBiasAdj', msb=5, lsb=0, accessibility='rw'))
r.AddBitField(BitField(name='AfeCLCBP', msb=11, lsb=6, accessibility='rw'))
r.AddBitField(BitField(name='AfeCLCBN', msb=17, lsb=12, accessibility='rw'))
r.AddBitField(BitField(name='AfeCLCBNC', msb=23, lsb=18, accessibility='rw'))
r.AddBitField(BitField(name='AfeCLCFB', msb=29, lsb=24, accessibility='rw'))
r.AddBitField(BitField(msb=31, lsb=30, unused=True))

# AFExCLC1
r = RegisterTemplate(nameTemplate='AFExCLC1', registerMemorySlot=24, size=8, description='Low current CSA bias register 1')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AfeCLCRef', msb=5, lsb=0, accessibility='rw'))
r.AddBitField(BitField(msb=7, lsb=6, unused=True))

# AFExVPC
r = RegisterTemplate(nameTemplate='AFExVPC', registerMemorySlot=25, size=32, description='Valid pulse count register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExVPC', msb=31, lsb=0, accessibility='r'))

# AFExTPC
r = RegisterTemplate(nameTemplate='AFExTPC', registerMemorySlot=26, size=32, description='Total pulse count register')
p.AddRegisterTemplate(r)

r.AddBitField(BitField(name='AFExTPC', msb=31, lsb=0, accessibility='r'))










''' Check the peripheral templates for errors '''
m.CheckPeripheralTemplates()



''' Create Peripherals from PeripheralTemplates and add them to the memory map '''
m.CreatePeripheral(nameTemplate='SYSTEM', nameIndex='', peripheralMemorySlot=0, interruptPriority=None)
GPIO1 = m.CreatePeripheral(nameTemplate='GPIOx', nameIndex=1, peripheralMemorySlot=1, interruptPriority=3)	# GPIO1
m.CreatePeripheral(nameTemplate='SPIx', nameIndex=0, peripheralMemorySlot=2, interruptPriority=4)	# SPI0
m.CreatePeripheral(nameTemplate='UARTx', nameIndex=0, peripheralMemorySlot=3, interruptPriority=5)	# UART0
m.CreatePeripheral(nameTemplate='TIMERx', nameIndex=0, peripheralMemorySlot=4, interruptPriority=6)	# TIMER0
m.CreatePeripheral(nameTemplate='TIMERx', nameIndex=1, peripheralMemorySlot=5, interruptPriority=7)	# TIMER1

GPIO2 = m.CreatePeripheral(nameTemplate='GPIOx', nameIndex=2, peripheralMemorySlot=6, interruptPriority=8)	# GPIO2
GPIO3 = m.CreatePeripheral(nameTemplate='GPIOx', nameIndex=3, peripheralMemorySlot=7, interruptPriority=9)	# GPIO3
GPIO4 = m.CreatePeripheral(nameTemplate='GPIOx', nameIndex=4, peripheralMemorySlot=8, interruptPriority=10)	# GPIO4
GPIO5 = m.CreatePeripheral(nameTemplate='GPIOx', nameIndex=5, peripheralMemorySlot=9, interruptPriority=11)	# GPIO5
m.CreatePeripheral(nameTemplate='NNx', nameIndex=0, peripheralMemorySlot=10, interruptPriority=12)	# NN0
m.CreatePeripheral(nameTemplate='SPIx', nameIndex=1, peripheralMemorySlot=11, interruptPriority=13)	# SPI1
m.CreatePeripheral(nameTemplate='UARTx', nameIndex=1, peripheralMemorySlot=12, interruptPriority=14)	# UART1
m.CreatePeripheral(nameTemplate='TIMERx', nameIndex=2, peripheralMemorySlot=13, interruptPriority=15)	# TIMER2
m.CreatePeripheral(nameTemplate='TIMERx', nameIndex=3, peripheralMemorySlot=14, interruptPriority=16)	# TIMER3
m.CreatePeripheral(nameTemplate='I2Cx', nameIndex=0, peripheralMemorySlot=15, interruptPriority=17)	# I2C0

m.CreatePeripheral(nameTemplate='AFEx', nameIndex=0, peripheralMemorySlot=16, interruptPriority=18)	# AFE0
m.CreatePeripheral(nameTemplate='AFEx', nameIndex=1, peripheralMemorySlot=17, interruptPriority=19)	# AFE1
m.CreatePeripheral(nameTemplate='AFEx', nameIndex=2, peripheralMemorySlot=18, interruptPriority=20)	# AFE2
m.CreatePeripheral(nameTemplate='AFEx', nameIndex=3, peripheralMemorySlot=19, interruptPriority=21)	# AFE3
m.CreatePeripheral(nameTemplate='AFEx', nameIndex=4, peripheralMemorySlot=20, interruptPriority=22)	# AFE4
m.CreatePeripheral(nameTemplate='AFEx', nameIndex=5, peripheralMemorySlot=21, interruptPriority=23)	# AFE5
m.CreatePeripheral(nameTemplate='AFEx', nameIndex=6, peripheralMemorySlot=22, interruptPriority=24)	# AFE6
m.CreatePeripheral(nameTemplate='AFEx', nameIndex=7, peripheralMemorySlot=23, interruptPriority=25)	# AFE7

m.CreatePeripheral(nameTemplate='PC', nameIndex='', peripheralMemorySlot=24, interruptPriority=None)	# PC (Pulse Counter)

GPIO6 = m.CreatePeripheral(nameTemplate='GPIOx', nameIndex=6, peripheralMemorySlot=25, interruptPriority=26)	# GPIO6
GPIO7 = m.CreatePeripheral(nameTemplate='GPIOx', nameIndex=7, peripheralMemorySlot=26, interruptPriority=27)	# GPIO7
GPIO8 = m.CreatePeripheral(nameTemplate='GPIOx', nameIndex=8, peripheralMemorySlot=27, interruptPriority=28)	# GPIO8






''' Add pins to the GPIO ports (and optionally change the GPIO port sizes) '''
''' WARNING: Look at the documentation for PinConfigurator.__init__() for important instructions on how to use the function, especially concerning the funcIOType argument '''
# GPIO1
GPIO1.ChangeGPIOPortSize(8)

GPIO1.AddPin(PinConfigurator(pinNumber=0, primaryName='CS_FLASH', funcName='', funcIOType='',	rstOUT=1, rstDIR=1, rstSEL=0, rstREN=0, description='Chip select pin for SPI flash memory'))
GPIO1.AddPin(PinConfigurator(pinNumber=1, primaryName='', funcName='MISO0', funcIOType='io',	rstOUT=0, rstDIR=0, rstSEL=1, rstREN=0, description='SPI0 Master In Slave Out (connected to SPI flash memory)'))
GPIO1.AddPin(PinConfigurator(pinNumber=2, primaryName='', funcName='MOSI0', funcIOType='o',		rstOUT=0, rstDIR=0, rstSEL=1, rstREN=0, description='SPI0 Master Out Slave In (connected to SPI flash memory)'))
GPIO1.AddPin(PinConfigurator(pinNumber=3, primaryName='', funcName='SCK0', funcIOType='o',		rstOUT=0, rstDIR=0, rstSEL=1, rstREN=0, description='SPI0 serial clock (connected to SPI flash memory)'))
GPIO1.AddPin(PinConfigurator(pinNumber=4, primaryName='', funcName='TX0', funcIOType='o',		rstOUT=0, rstDIR=0, rstSEL=1, rstREN=0, description='UART0 transmitter (default forth interpreter interface)'))
GPIO1.AddPin(PinConfigurator(pinNumber=5, primaryName='', funcName='RX0', funcIOType='io',		rstOUT=0, rstDIR=0, rstSEL=1, rstREN=0, description='UART0 receiver (default forth interpreter interface)'))
GPIO1.AddPin(PinConfigurator(pinNumber=6, primaryName='', funcName='TRAP', funcIOType='o',		rstOUT=0, rstDIR=0, rstSEL=1, rstREN=0, description='CPU trap state'))
GPIO1.AddPin(PinConfigurator(pinNumber=7, primaryName='BOOT', funcName='', funcIOType='',		rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='Boot select pin (Boots to forth interpreter when HIGH, boots from SPI flash when LOW)'))

# GPIO2
GPIO2.ChangeGPIOPortSize(8)

GPIO2.AddPin(PinConfigurator(pinNumber=0, primaryName='', funcName='', funcIOType='',			rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description=''))
GPIO2.AddPin(PinConfigurator(pinNumber=1, primaryName='', funcName='MISO1', funcIOType='io',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='SPI1 Master In Slave Out'))
GPIO2.AddPin(PinConfigurator(pinNumber=2, primaryName='', funcName='MOSI1', funcIOType='o',		rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='SPI1 Master Out Slave In'))
GPIO2.AddPin(PinConfigurator(pinNumber=3, primaryName='', funcName='SCK1', funcIOType='o',		rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='SPI1 serial clock'))
GPIO2.AddPin(PinConfigurator(pinNumber=4, primaryName='', funcName='TX1', funcIOType='o',		rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='UART1 transmitter'))
GPIO2.AddPin(PinConfigurator(pinNumber=5, primaryName='', funcName='RX1', funcIOType='io',		rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='UART1 receiver'))
GPIO2.AddPin(PinConfigurator(pinNumber=6, primaryName='', funcName='CLKO', funcIOType='o',		rstOUT=0, rstDIR=0, rstSEL=1, rstREN=0, description='Clock output (outputs a selectable clock signal for external measurement and use)'))
GPIO2.AddPin(PinConfigurator(pinNumber=7, primaryName='SL0', funcName='', funcIOType='',			rstOUT=0, rstDIR=1, rstSEL=0, rstREN=0, description=''))

# GPIO3
GPIO3.ChangeGPIOPortSize(8)

GPIO3.AddPin(PinConfigurator(pinNumber=0, primaryName='', funcName='T0CMP0', funcIOType='o',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER0 Compare 0 pin (for PWM generation)'))
GPIO3.AddPin(PinConfigurator(pinNumber=1, primaryName='', funcName='T0CMP1', funcIOType='o',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER0 Compare 1 pin (for PWM generation)'))
GPIO3.AddPin(PinConfigurator(pinNumber=2, primaryName='', funcName='T0CAP0', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER0 input capture 0 pin'))
GPIO3.AddPin(PinConfigurator(pinNumber=3, primaryName='', funcName='T0CAP1', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER0 input capture 1 pin'))
GPIO3.AddPin(PinConfigurator(pinNumber=4, primaryName='', funcName='T1CMP0', funcIOType='o',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER1 Compare 0 pin (for PWM generation)'))
GPIO3.AddPin(PinConfigurator(pinNumber=5, primaryName='', funcName='T1CMP1', funcIOType='o',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER1 Compare 1 pin (for PWM generation)'))
GPIO3.AddPin(PinConfigurator(pinNumber=6, primaryName='', funcName='T1CAP0', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER1 input capture 0 pin'))
GPIO3.AddPin(PinConfigurator(pinNumber=7, primaryName='', funcName='T1CAP1', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER1 input capture 1 pin'))

# GPIO4
GPIO4.ChangeGPIOPortSize(8)

GPIO4.AddPin(PinConfigurator(pinNumber=0, primaryName='', funcName='T2CMP0', funcIOType='o',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER2 Compare 0 pin (for PWM generation)'))
GPIO4.AddPin(PinConfigurator(pinNumber=1, primaryName='', funcName='T2CMP1', funcIOType='o',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER2 Compare 1 pin (for PWM generation)'))
GPIO4.AddPin(PinConfigurator(pinNumber=2, primaryName='', funcName='T2CAP0', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER2 input capture 0 pin'))
GPIO4.AddPin(PinConfigurator(pinNumber=3, primaryName='', funcName='T2CAP1', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER2 input capture 1 pin'))
GPIO4.AddPin(PinConfigurator(pinNumber=4, primaryName='', funcName='T3CMP0', funcIOType='o',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER3 Compare 0 pin (for PWM generation)'))
GPIO4.AddPin(PinConfigurator(pinNumber=5, primaryName='', funcName='T3CMP1', funcIOType='o',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER3 Compare 1 pin (for PWM generation)'))
GPIO4.AddPin(PinConfigurator(pinNumber=6, primaryName='', funcName='T3CAP0', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER3 input capture 0 pin'))
GPIO4.AddPin(PinConfigurator(pinNumber=7, primaryName='', funcName='T3CAP1', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='TIMER3 input capture 1 pin'))

# GPIO5
GPIO5.ChangeGPIOPortSize(8)

GPIO5.AddPin(PinConfigurator(pinNumber=0, primaryName='', funcName='SDA0', funcIOType='io',			rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='I2C0 serial data'))
GPIO5.AddPin(PinConfigurator(pinNumber=1, primaryName='', funcName='SCL0', funcIOType='io',			rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='I2C0 serial clock'))
GPIO5.AddPin(PinConfigurator(pinNumber=2, primaryName='SH0', funcName='', funcIOType='',			rstOUT=1, rstDIR=1, rstSEL=0, rstREN=0, description=''))
GPIO5.AddPin(PinConfigurator(pinNumber=3, primaryName='SH1', funcName='', funcIOType='',			rstOUT=1, rstDIR=1, rstSEL=0, rstREN=0, description=''))
GPIO5.AddPin(PinConfigurator(pinNumber=4, primaryName='', funcName='PC0', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='Pulse counter input 0'))
GPIO5.AddPin(PinConfigurator(pinNumber=5, primaryName='', funcName='PC1', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='Pulse counter input 1'))
GPIO5.AddPin(PinConfigurator(pinNumber=6, primaryName='', funcName='PC2', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='Pulse counter input 2'))
GPIO5.AddPin(PinConfigurator(pinNumber=7, primaryName='', funcName='PC3', funcIOType='i',	rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='Pulse counter input 3'))

# GPIO6
GPIO6.ChangeGPIOPortSize(8)

GPIO6.AddPin(PinConfigurator(pinNumber=0, primaryName='', funcName='AFE0DTP0', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE0 digital test port 0'))
GPIO6.AddPin(PinConfigurator(pinNumber=1, primaryName='', funcName='AFE1DTP0', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE1 digital test port 0'))
GPIO6.AddPin(PinConfigurator(pinNumber=2, primaryName='', funcName='AFE2DTP0', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE2 digital test port 0'))
GPIO6.AddPin(PinConfigurator(pinNumber=3, primaryName='', funcName='AFE3DTP0', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE3 digital test port 0'))
GPIO6.AddPin(PinConfigurator(pinNumber=4, primaryName='', funcName='AFE4DTP0', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE4 digital test port 0'))
GPIO6.AddPin(PinConfigurator(pinNumber=5, primaryName='', funcName='AFE5DTP0', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE5 digital test port 0'))
GPIO6.AddPin(PinConfigurator(pinNumber=6, primaryName='', funcName='AFE6DTP0', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE6 digital test port 0'))
GPIO6.AddPin(PinConfigurator(pinNumber=7, primaryName='', funcName='AFE7DTP0', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE7 digital test port 0'))

# GPIO7
GPIO7.ChangeGPIOPortSize(8)

GPIO7.AddPin(PinConfigurator(pinNumber=0, primaryName='', funcName='AFE0DTP1', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE0 digital test port 1'))
GPIO7.AddPin(PinConfigurator(pinNumber=1, primaryName='', funcName='AFE1DTP1', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE1 digital test port 1'))
GPIO7.AddPin(PinConfigurator(pinNumber=2, primaryName='', funcName='AFE2DTP1', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE2 digital test port 1'))
GPIO7.AddPin(PinConfigurator(pinNumber=3, primaryName='', funcName='AFE3DTP1', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE3 digital test port 1'))
GPIO7.AddPin(PinConfigurator(pinNumber=4, primaryName='', funcName='AFE4DTP1', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE4 digital test port 1'))
GPIO7.AddPin(PinConfigurator(pinNumber=5, primaryName='', funcName='AFE5DTP1', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE5 digital test port 1'))
GPIO7.AddPin(PinConfigurator(pinNumber=6, primaryName='', funcName='AFE6DTP1', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE6 digital test port 1'))
GPIO7.AddPin(PinConfigurator(pinNumber=7, primaryName='', funcName='AFE7DTP1', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE7 digital test port 1'))

# GPIO8
GPIO8.ChangeGPIOPortSize(8)

GPIO8.AddPin(PinConfigurator(pinNumber=0, primaryName='', funcName='AFE0BRST', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE0 baseline reset'))
GPIO8.AddPin(PinConfigurator(pinNumber=1, primaryName='', funcName='AFE1BRST', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE1 baseline reset'))
GPIO8.AddPin(PinConfigurator(pinNumber=2, primaryName='', funcName='AFE2BRST', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE2 baseline reset'))
GPIO8.AddPin(PinConfigurator(pinNumber=3, primaryName='', funcName='AFE3BRST', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE3 baseline reset'))
GPIO8.AddPin(PinConfigurator(pinNumber=4, primaryName='', funcName='AFE4BRST', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE4 baseline reset'))
GPIO8.AddPin(PinConfigurator(pinNumber=5, primaryName='', funcName='AFE5BRST', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE5 baseline reset'))
GPIO8.AddPin(PinConfigurator(pinNumber=6, primaryName='', funcName='AFE6BRST', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE6 baseline reset'))
GPIO8.AddPin(PinConfigurator(pinNumber=7, primaryName='', funcName='AFE7BRST', funcIOType='o', rstOUT=0, rstDIR=0, rstSEL=0, rstREN=0, description='AFE7 baseline reset'))


''' Check the peripherals for errors '''
m.CheckPeripherals()



''' Generate output files'''
m.Generate(test=False, force=True, saveHardware=False, saveSoftware=True)
