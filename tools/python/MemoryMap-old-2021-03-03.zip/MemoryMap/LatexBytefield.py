from Peripheral import PeripheralTemplate, Peripheral
from Register import RegisterTemplate, Register
from BitField import BitField
import datetime

class LatexBytefield():
	
	def __init__(self):
		return
	
	def GenerateUserGuide(self, texHeaderPath, memoryMap):
		s = ''
		
		f = open(texHeaderPath, 'r', newline='\n')
		s += f.read()
		f.close()

		asicName = memoryMap.AsicName.title()

		# Add the margins, headers, and footers
		s += r'\lhead{MCU User Guide for ' + asicName + '}' + '\n'
		s += r'\chead{}' + '\n'
		s += r'\rhead{\thepage\ of \pageref{LastPage}}' + '\n'
		s += r'\lfoot{\small{University of Nebraska--Lincoln}}' + '\n'
		s += r'\cfoot{}' + '\n'
		s += r'\rfoot{\small{Department of Electrical \& Computer Engineering}}' + '\n'
		s += r'\renewcommand{\footrulewidth}{0.5pt}' + '\n\n\n\n'
		
		# Begin the document
		s += '\\begin{document}\n\n'
		
		# Add the title page
		s += '\\vspace*{30ex}\n'
		s += '\\begin{center}\n\n'
		s += '\\textbf{MCU User Guide for ' + asicName + r'} \\' + '\n'
		s += '\\vspace{2ex}\n'
		s += 'Revised ' + datetime.datetime.now().strftime('%B %d, %Y') + r' \\' + '\n\n'
		s += '\\vspace{8ex}\n\n'
		s += 'Univeristy of Nebraska--Lincoln' + r' \\' + '\n'
		s += r'Department of Electrical \& Computer Engineering' + r' \\' + '\n\n'
		s += '\\vspace{4ex}\n\n'
		s += '\\end{center}\n\n'
		
		# Add the table of contents
		s += '\\newpage\n'
		s += '\\tableofcontents\n'
		s += '\\newpage\n\n'

		# Add the system configuration
		s += self.generateConfiguration(memoryMap)
		
		# Add the memory map
		s += self.generateMemoryMap(memoryMap)

		# Add the startup and reset behavior
		s += self.generateStartupReset(memoryMap)

		# Add the interrupts
		s += self.generateInterrupts(memoryMap)
		
		# Add the pin configuration
		s += self.generatePinConfiguration(memoryMap)

		# Add the Forth interpreter section
		s += self.generateForth(memoryMap)

		# Add the software development section
		s += self.generateSoftware(memoryMap)

		# Add the programming section
		s += self.generateProgramming(memoryMap)
		
		# Get all peripheral templates and add them to the document
		peripheralTemplates = []
		for p in memoryMap.Peripherals:
			if p.Template not in peripheralTemplates:
				peripheralTemplates.append(p.Template)
		for pt in peripheralTemplates:
			s += self.generatePeripheralTemplate(pt)

		## Add the peripherals
		#for p in memoryMap.Peripherals:
		#	s += self.generatePeripheral(p)

		# Add the peripheral and register location data
		s += self.generateRegisterMemoryMap(memoryMap.Peripherals)

		# End the document
		s += '\\end{document}\n'
		
		return s
	
	def generateRegisterMemoryMap(self, peripherals, useAlternatingColoredRows=True):
		# Begin with the section
		s = '\\section{Register and Peripheral Memory Map} \\label{s:regMemMap}\n'

		for p in peripherals:
			s += '\\subsection{' + p.Name.replace('_', '\\_') + ' Peripheral}\n'
			
			# Add the base address and the peripheral memory slot
			s += 'Base Address = ' + self.fmthex(p.BaseAddress) + ', Peripheral Memory Slot = ' + str(p.PeripheralMemorySlot) + r' \\' + '\n'

			# Add the table of all the registers
			s += '\\begin{tabularx}{\\textwidth}{ l l l l X }\n'
			s += r'Register & Address & Slot & Offset (bytes) & Size (bytes)' + r' \\ \hline' + '\n'
			
			thisRowColored = False

			for r in p.Registers:
				if useAlternatingColoredRows is True and thisRowColored is True:
					s += r'\rowcolor{tablehighlightcolor}'
				s += '\\hyperref[ss:' + r.Template.NameTemplate.replace('_', '') + ']{' + self.truetype(r.Name) + r'} & '
				s += self.fmthex(r.Address) + r' & '
				s += str(r.RegisterMemorySlot) + r' & '
				s += str(r.Offset) + r' & '
				s += str(r.Size // 8) + r' \\' + '\n'

				thisRowColored = not thisRowColored
			
			# Remove the \\ from the last entry
			s = s[:-3] + '\n'
			s += '\\end{tabularx}\n\n'
		
		return s
	
	def generatePeripheralTemplate(self, peripheralTemplate):
		s = ''
		
		# Begin with the section
		s += '\\section{' + peripheralTemplate.NameTemplate.replace('_', '\\_') + ' Peripheral}\n'

		# Add the description
		s += '\\noindent\n'
		s += peripheralTemplate.Description.replace('_', '\\_').replace('>', '$>$') + '\n\n'
		
		# Add the register subsections
		for r in peripheralTemplate.RegisterTemplates:
			s += self.generateRegisterTemplate(r)
		
		# Make a new page
		s += '\\newpage\n\n'
		
		return s
	
	def generatePeripheral(self, peripheral, useAlternatingColoredRows=True):
		s = ''
		
		# Begin with the section
		s += '\\section{' + peripheral.Name.replace('_', '\\_') + ' Peripheral}\n'
		
		# Add the base address and the peripheral memory slot
		s += 'Base Address = ' + self.fmthex(peripheral.BaseAddress) + ', Peripheral Memory Slot = ' + str(peripheral.PeripheralMemorySlot) + r' \\' + '\n'

		# Add the description
		s += '\\noindent\n'
		s += peripheral.Description.replace('_', '\\_').replace('>', '$>$') + '\n\n'
		
		# Add the table of all the registers
		s += '\\begin{tabularx}{\\textwidth}{ l l l l X }\n'
		s += r'Register & Address & Slot & Offset (bytes) & Size (bytes)' + r' \\ \hline' + '\n'
		
		thisRowColored = False

		for r in peripheral.Registers:
			if useAlternatingColoredRows is True and thisRowColored is True:
				s += r'\rowcolor{tablehighlightcolor}'
			s += '\\hyperref[ss:' + r.Name.replace('_', '') + ']{' + self.truetype(r.Name) + r'} & '
			s += self.fmthex(r.Address) + r' & '
			s += str(r.RegisterMemorySlot) + r' & '
			s += str(r.Offset) + r' & '
			s += str(r.Size // 8) + r' \\' + '\n'

			thisRowColored = not thisRowColored
		
		# Remove the \\ from the last entry
		s = s[:-3] + '\n'
		s += '\\end{tabularx}\n\n'
		
		# Make a new page
		s += '\\newpage\n\n'
		
		# Add the register subsections
		for r in peripheral.Registers:
			s += self.generateRegister(r)
		
		# Make a new page
		s += '\\newpage\n\n'
		
		return s
	
	def generateRegisterTemplate(self, registerTemplate):
		s = ''
		
		# Begin with the subsection
		s += '\\subsection{' + registerTemplate.NameTemplate.replace('_', '\\_') + ' Register} \\label{ss:' + registerTemplate.NameTemplate.replace('_', '') + '}\n'
		
		# Add the memory address, and register slot, offset, and size
		multipleBytesStr = ''
		if registerTemplate.Size > 8:
			multipleBytesStr = 's'
		s += '\\noindent\n'
		s += 'Register Memory Slot = ' + str(registerTemplate.RegisterMemorySlot) + ', Offset = ' + str(registerTemplate.Offset) + ' bytes, Size = ' + str(registerTemplate.Size) + ' bits (' + str(registerTemplate.Size // 8) + ' byte' + multipleBytesStr + ')' + r' \\' + '\n'

		# Add the description
		s += registerTemplate.Description.replace('_', '\\_').replace('>', '$>$') + '\n\n'
		
		# Add the bytefield
		s += self.generateBytefield(registerTemplate)
		
		# Add the value descriptions table
		s += self.generateValueDescriptionsTable(registerTemplate)
		
		s += '\n'
		
		return s

	def generateRegister(self, register):
		s = ''
		
		# Begin with the subsection
		s += '\\subsection{' + register.Name.replace('_', '\\_') + ' Register} \\label{ss:' + register.Name.replace('_', '') + '}\n'
		
		# Add the memory address, and register slot, offset, and size
		multipleBytesStr = ''
		if register.Size > 8:
			multipleBytesStr = 's'
		s += '\\noindent\n'
		s += 'Address = ' + self.fmthex(register.Address) + ', Register Memory Slot = ' + str(register.RegisterMemorySlot) + ', Offset = ' + str(register.Offset) + ' bytes, Size = ' + str(register.Size) + ' bits (' + str(register.Size // 8) + ' byte' + multipleBytesStr + ')' + r' \\' + '\n'

		# Add the description
		s += register.Description.replace('_', '\\_').replace('>', '$>$') + '\n\n'
		
		# Add the bytefield
		s += self.generateBytefield(register)
		
		# Add the value descriptions table
		s += self.generateValueDescriptionsTable(register)
		
		s += '\n'
		
		return s
		
	
	def generateBytefield(self, register):
		s = ''
		
		if len(register.BitFields) < 1:
			return ''
		
		# Begin with the prelude
		s += '\\begin{center}\n'
		s += '\\begin{bytefield}[endianness=big, bitwidth=0.125\\linewidth]{8}\n'
		
		# Add the bytefield lines
		for i in reversed(range(4)):
			s += self.makeBytefieldLine(register, i)
		
		# Add the postlude
		s += '\\end{bytefield}\n'
		s += '\\end{center}\n'
		
		return s
	
	def makeBytefieldLine(self, register, byteNum):
		s = ''
		if byteNum >= 2 and register.Size <= 16:
			return ''
		
		if byteNum == 1 and register.Size <= 8:
			return ''
		
		lineLSB = byteNum * 8
		lineMSB = lineLSB + 7
		
		# Make the bit header
		s += '\\bitheader[lsb=' + str(lineLSB) + ']{' + str(lineLSB) + '-' + str(lineMSB) + '}' + r' \\' + '\n'
		
		# Make the bit fields
		prevBF = None
		prevBFlen = 0
		for bitNum in reversed(range(lineLSB, lineMSB + 1)):
			thisBF = register.GetBitFieldAt(bitNum)
			
			if thisBF == prevBF:
				prevBFlen += 1
			else:
				# Create the old bit field if its length != 0
				s += self.makeBitField(prevBF, prevBFlen) + r' & '
				prevBFlen = 1
			prevBF = thisBF
		
		# Make the last bit field
		if prevBF is not None:
			s += self.makeBitField(prevBF, prevBFlen) + r' \\' + '\n'
		else:
			s += '\\bitbox{8}{}' + r' \\' + '\n'
		
		# Make the read/write/reset fields
		for bitNum in reversed(range(lineLSB, lineMSB + 1)):
			thisBF = register.GetBitFieldAt(bitNum)
			
			if thisBF is None:
				s += '\\bitbox[t]{1}{}' + r' & '
			elif thisBF.Unused:
				s += '\\bitbox[t]{1}{}' + r' & '
			else:
				s += '\\bitbox[t]{1}{\\tiny ' + thisBF.Accessibility + '-(' + str(register.GetBitResetValue(bitNum)) + ')}' + r' & '
		s = s[:-3] + r' \\' + '\n\n'
		
		return s
	
	def makeBitField(self, bitField, length):
		if bitField is None:
			return '\\bitbox{' + str(length) + '}{}'
			
		if bitField.Unused:
			return '\\bitbox{' + str(length) + '}{\\textit{\\color{lightgray}Unused}}'
		
		return '\\bitbox{' + str(length) + '}' + self.truetype(bitField.Name)
	
	def generateValueDescriptionsTable(self, register, useAlternatingColoredRows=True):
		s = ''
		
		if len(register.BitFields) < 1:
			return ''
		
		skip = True
		for bf in register.BitFields:
			if bf.Unused:
				continue
			if bf.SameNameAsRegister and (len(bf.ValueDescriptions) == 0):
				continue
			skip = False
		
		if skip:
			return ''
		
		s += '\\begin{tabularx}{\\textwidth}{ l l l X }\n'
		s += r'\textbf{Bitfield} & \textbf{Range} & \multicolumn{2}{X}{\textbf{Description}} \\ \hline' + '\n'
		
		for i, bf in enumerate(register.BitFields):
			if bf.Unused is True:
				s += r'\textit{Unused} & '
			else:
				s += self.truetype(bf.Name) + r' & '
			
			if bf.Size > 1:
				s += 'Bits ' + str(bf.MSB) + '-' + str(bf.LSB)
			else:
				s += 'Bit ' + str(bf.MSB)
			s += r' & '
			s += '\\multicolumn{2}{X}{' + bf.Description.replace('_', '\\_').replace('>', '$>$') + '}' + r' \\' + '\n'
			
			thisRowColored = False

			for vd in bf.ValueDescriptions:
				value, description, name = vd
				
				s += r' & & '

				if useAlternatingColoredRows is True and thisRowColored is True:
					s += r'\cellcolor{tablehighlightcolor}'

				s += self.fmtbin(value, bf.Size, noPrefix=True) + r' & '
				
				if useAlternatingColoredRows is True and thisRowColored is True:
					s += r'\cellcolor{tablehighlightcolor}'

				if len(name) > 0:
					s += self.truetype(name) + ': '
				
				s += description.replace('_', '\\_')
				s += r' \\' + '\n'

				thisRowColored = not thisRowColored
			
			if (i + 1) < len(register.BitFields):
				# Not the last line
				s += r'\hline' + '\n'
		
		# Remove the \\ from the last entry
		s = s[:-3] + '\n'
		s += '\\end{tabularx}\n'
		
		return s
	
	def generateStartupReset(self, memoryMap):
		s = ''

		s += '\\section{Startup and Reset Behavior}\n\n'
		s += 'To place the MCU in reset mode, drive the resetn pin LOW (asserted). To take the MCU out of reset mode, let the resetn pin go high (deasserted). The resetn pin has an internal 47 k$\\Omega$ pullup resistor which constantly attempts to pull the resetn pin HIGH. If the user does not wish to use the resetn pin, it is safe to leave it unconnected.\n\n'
		s += 'When the MCU is first powered up, a power-on reset (POR) circuit resets the circuit. As the core voltage, beginning at 0 V, begins to climb, the POR circuit does not assert the internal reset. Once the core voltage reaches a particular value (which is temperature and process dependent, but typically around 0.7 V), the POR circuit asserts the internal reset signal for about 20 ns and then deasserts it. If either the resetn pin or the POR reset signal is asserted, the MCU will be in reset mode.\n\n'
		s += 'When the MCU comes out of reset, it immediately begins to boot from the ROM, setting the program counter to address ' + self.fmthex(0) + '. If the BOOT pin is LOW, the boot software launches a Forth interpreter from the ROM which communicates over UART0 at 2,048 baud (see Section \\ref{s:forth} for details concerning the Forth interpreter). If the BOOT pin is HIGH, the boot sofware loads and executes the program stored on an external SPI flash on SPI0 (see Section \\ref{s:programming} for details on how to program the MCU). When the boot program loads the program stored in the SPI flash, it completely fills the RAM with the contents of the SPI flash from the beginning of the RAM to the end using an address-to-address copy. After the boot program has loaded the program stored in the SPI flash into RAM, it jumps (moves the program counter) to address ' + self.fmthex(memoryMap.RamProgramStartAddress) + ' and begins executing the code.\n\n'

		s += '\\newpage\n\n'

		return s
	
	def generateForth(self, memoryMap):
		s = ''

		s += '\\section{Forth Interpreter} \\label{s:forth}\n\n'

		s += 'When the MCU comes out of reset and the BOOT pin is LOW, the MCU boots to an interactive Forth interpreter based on the Forth language. Forth is a stack-based language where variables are pushed to a stack in LIFO (last in, first out) order. When a variable is set, it is pushed to the top of the stack (TOS). When a variable is used, it is popped (or consumed) from the TOS. Functions that take arguments pop them from the TOS. Functions that have return values push them to the TOS (after first popping its arguments). Variables are not assigned names, and the only way of distinguishing them from one another is by their order on the stack. All variables are treated as 32-bit signed integers. Variables may be pushed to the stack through the command line by simply typing the variable value into the interpreter as a plain text integer value or as a plain text hexadecimal value. Hexadecimal values must be preceded by the string ' + self.truetype('0x') + ' without spaces in between, but the value may be upper or lower case and does not need leading zeros. Variables are not pushed or popped and functions are not executed until a newline (or line feed) ' + self.truetype('{\\textbackslash}n') + ' character is received, at which point the entire received line will be executed in order. New functions may be declared, and may use the stack and any already defined functions to perform their procedures. If the Forth interpreter does not recognize an input as a variable or a function, it prints the ' + self.truetype('?') + ' char over the UART.\n\n'

		s += 'The Forth interpreter contained in the ROM of the MCU communicates over UART0 at 2,048 baud. The baud may be changed by reconfiguring SMCLK and the UART0 peripheral. When the Forth interpreter first starts up, it prints the string ``' + self.truetype('rv4th!{\\textbackslash}n\\textgreater') + '", and is then ready to receive characters over the UART. The Forth interpreter does not perform error handling on stack underflows. In the case of a stack underflow, it simply uses the value 0 as the TOS. By default, the echo is enabled, which repeates all characters received by the Forth interpreter back to the host. This is useful for typing into a terminal emulator manually, but may be switched off with the command: ' + self.truetype('0 echo') + '\n\n'

		s += 'Several useful built-in Forth functions are listed below. The syntax is read as follows: The Forth function keyword is surrounded by quotations (though you do not actually type the quotes into the Forth interpreter), and is followed by the list of arguments and return values in parentheses. Left of the double dash is the list of arguments in the order that they would be typed into the Forth interpreter (reverse stack order), and right of the double dash is the list of return values in reverse stack order. Reverse stack order means that the rightmost item is at the TOS, and items to the left of it are below it on the stack. Arguments are always popped from the stack before the function executes, and return values are always pushed to the stack after the function finishes.\n\n'

		# Memory access
		s += '\\subsection{Memory Access Functions}\n'
		s += '\\begin{itemize}\n\n'

		s += self.generateForthCommand('@', 'Read directly from the memory address and push the value to the TOS',
			argumentsTextOrdering=[['addr', 'The address to read from (must be aligned to a 4-byte (32-bit) boundary)']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('!', 'Write directly to memory address',
			argumentsTextOrdering=[['val', 'The value to write to the memory address'], ['addr', 'The address to write to (must be aligned to a 4-byte (32-bit) boundary)']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('+!', 'Add to value, direct memory access (*addr += val)',
			argumentsTextOrdering=[['val', 'The value to add to the value at the memory address'], ['addr', 'The address to write to (must be aligned to a 4-byte (32-bit) boundary)']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('sbi', 'Set bit, direct memory access (*addr {\\textbar}= (1 $<<$ bitnum))',
			argumentsTextOrdering=[['bitnum', 'The bit number'], ['addr', 'The address to write to (must be aligned to a 4-byte (32-bit) boundary)']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('cbi', 'Clear bit, direct memory access (*addr {\\&}= \\textasciitilde (1 $<<$ bitnum))',
			argumentsTextOrdering=[['bitnum', 'The bit number'], ['addr', 'The address to write to (must be aligned to a 4-byte (32-bit) boundary)']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('mask', 'Change only masked bits, direct memory access (*addr = (*addr {\\&} {\\textasciitilde}bitmask) \\textbar (val {\\&} bitmask))',
			argumentsTextOrdering=[['bitmask', 'The bit mask. Only bits with 1s can be changed'], ['val', 'The value to write (only masked bits will be written)'], ['addr', 'The address to write to (must be aligned to a 4-byte (32-bit) boundary)']],
			returnValuesTextOrder=None)
		
		s += '\\end{itemize}\n\n'

		# Printing
		s += '\\subsection{Print and Input Functions}\n'
		s += '\\begin{itemize}\n\n'
		
		s += self.generateForthCommand('.', 'Prints the TOS as an integer',
			argumentsTextOrdering=[['val', 'The value to print']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('h.', 'Prints the TOS as a hex string', 				argumentsTextOrdering=[['val', 'The value to print']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('echo', 'Change the echo state, which controls whether the Forth interpreter repeats all of its received characters',
			argumentsTextOrdering=[['bool', 'If 0, does not echo. Otherwise, it does']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('emit', 'Prints the char at the TOS (integers are mapped to their ASCII counterparts)',
			argumentsTextOrdering=[['val', 'The ASCII value of the char to print']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('key', 'Waits for a char over UART and pushes the ASCII value of the char to the TOS',
			argumentsTextOrdering=None,
			returnValuesTextOrder=[['char', 'The char that was received over UART']])

		s += self.generateForthCommand('list', 'Prints all currently available functions',
			argumentsTextOrdering=None,
			returnValuesTextOrder=None)
		
		s += '\\end{itemize}\n\n'

		# Arithmatic
		s += '\\subsection{Arithmetic Functions}\n'
		s += '\\begin{itemize}\n\n'
		
		s += self.generateForthCommand('+', 'Adds two numbers (val2 + val1)',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('-', 'Subtracts two numbers (val2 - val1)',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('*', 'Multiplies two numbers (val2 * val1)',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['retprodhi', 'Upper 32 bits of the return product'], ['retprodlo', 'Lower 32 bits of the return product']])
		
		s += self.generateForthCommand('/\\%', 'Divides two numbers with remainder (val2 / val1 and val2 \% val1)',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['retdiv', 'The integer division result'], ['retrem', 'The remainder (or modulo) result']])
		
		s += self.generateForthCommand('neg', 'Returns the negative (twos complement) of val',
			argumentsTextOrdering=[['val', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('abs', 'Absolute value (\\textbar val\\textbar)',
			argumentsTextOrdering=[['val', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += '\\end{itemize}\n\n'

		# Bitwise
		s += '\\subsection{Bitwise Logic Functions}\n'
		s += '\\begin{itemize}\n\n'

		s += self.generateForthCommand('$\\sim$', 'Bitwise complement ($\\sim$val)',
			argumentsTextOrdering=[['val', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']], nameTruetype=False)
		
		s += self.generateForthCommand('\\textbar', 'Bitwise or (val2 {\\textbar} val1)',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']], nameTruetype=False)
		
		s += self.generateForthCommand('{\\&}', 'Bitwise and (val2 {\\&} val1)',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']], nameTruetype=False)
		
		s += self.generateForthCommand('\\textasciicircum', 'Bitwise xor (val2 \\textasciicircum val1)',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']], nameTruetype=False)
		
		s += self.generateForthCommand('*2', 'Shift left 1 bit (val $<<$ 1)',
			argumentsTextOrdering=[['val', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('/2', 'Shift right 1 bit (val $>>$ 1)',
			argumentsTextOrdering=[['val', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('sll', 'Shift left logical (val $<<$ bits)',
			argumentsTextOrdering=[['val', 'Signed integer'], ['bits', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('srl', 'Shift right logical (val $>>$ bits), no sign extension',
			argumentsTextOrdering=[['val', 'Signed integer'], ['bits', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += '\\end{itemize}\n\n'

		# Comparisons
		s += '\\subsection{Comparison Functions}\n'
		s += '\\begin{itemize}\n\n'
		
		s += self.generateForthCommand('$>$', 'Greater than. Returns 1 if val2 $>$ val1, returns 0 otherwise.',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', '1 if true, 0 if false']])
		
		s += self.generateForthCommand('$<$', 'Less than. Returns 1 if val2 $<$ val1, returns 0 otherwise.',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', '1 if true, 0 if false']])
		
		s += self.generateForthCommand('==', 'Equals. Returns 1 if val2 == val1, returns 0 otherwise.',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', '1 if true, 0 if false']])
		
		s += '\\end{itemize}\n'

		# Boolean
		s += '\\subsection{Boolean Functions}\n'
		s += '\\begin{itemize}\n\n'
		
		s += self.generateForthCommand('not', 'Logical not (!val). Returns 1 if val is equal to 0, returns 0 otherwise',
			argumentsTextOrdering=[['val', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('and', 'Logical and (val2 \\&\\& val1). Returns 1 if val2 and val1 are both true (nonzero), returns 0 otherwise',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])

		s += self.generateForthCommand('or', 'Logical or (val2 {\\textbar}{\\textbar} val1). Returns 1 if val2 or val1 are true (nonzero), returns 0 otherwise',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += '\\end{itemize}\n'

		# Stack
		s += '\\subsection{Stack Manipulation Functions}\n'
		s += '\\begin{itemize}\n\n'
		
		s += self.generateForthCommand('dup', 'Duplicates the TOS (pops the TOS and then pushes the value to the TOS twice)',
			argumentsTextOrdering=[['val', 'Value to duplicate']],
			returnValuesTextOrder=[['val', 'The original TOS'], ['val', 'The duplicated value']])
		
		s += self.generateForthCommand('drop', 'Pops the TOS and sets it as the internal Forth ' + self.truetype('i') + ' value. Usually used to delete the TOS.',
			argumentsTextOrdering=[['val', 'The value that is dropped']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('swap', 'Swaps the TOS with the value below the TOS',
			argumentsTextOrdering=[['val2', 'Old value below the TOS'], ['val1', 'Old TOS']],
			returnValuesTextOrder=[['val1', 'Old TOS'], ['val2', 'Old value below the TOS']])
		
		s += self.generateForthCommand('over', 'Copies the value below the TOS and pushes it to the TOS',
			argumentsTextOrdering=[['val2', 'Signed Integer'], ['val1', 'Signed Integer']],
			returnValuesTextOrder=[['val2', 'Signed Integer'], ['val1', 'Signed Integer'], ['val2', 'Signed Integer']])
		
		s += self.generateForthCommand('tuck', 'Copies the TOS and inserts it two after the TOS',
			argumentsTextOrdering=[['val2', 'Signed Integer'], ['val1', 'Signed Integer']],
			returnValuesTextOrder=[['val1', 'Signed Integer'], ['val2', 'Signed Integer'], ['val1', 'Signed Integer']])
		
		s += self.generateForthCommand('roll', 'Removes value at index n of the stack and pushes it to the TOS (zero indexed)',
			argumentsTextOrdering=[['n', 'Stack index (zero indexed)']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('pick', 'Copies value at index n of the stack and pushes it to the TOS (zero indexed)',
			argumentsTextOrdering=[['n', 'Stack index (zero indexed)']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('depth', 'Gets size of stack and pushes it to the top of the stack (making the new stack size the value of TOS + 1)',
			argumentsTextOrdering=None,
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += '\\end{itemize}\n\n'

		# Flash
		s += '\\subsection{SPI Flash R/W and Programming Functions} \\label{ss:forthflash}\n'
		s += '\\begin{itemize}\n\n'

		s += self.generateForthCommand('fr', 'Reads data from the SPI flash.',
			argumentsTextOrdering=[['bin', 'If true (nonzero), transmits binary data, otherwise transmits ASCII hex string'], ['length', 'The number of bytes to read'], ['addr', 'The address in the SPI flash to begin reading from']],
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('fe', 'Erases a 256-byte page from the SPI flash memory. The start address must be 256-byte aligned.',
			argumentsTextOrdering=[['conf', 'If equal to 123, erases the page and returns 1, otherwise does not erase and returns 0'], ['addr', 'The start address of the page to erase in the SPI flash. Must be 256-byte aligned.']],
			returnValuesTextOrder=[['eraseSuccessful', 'Nonzero if successful, zero if failed']])
		
		s += self.generateForthCommand('fw', 'Writes data to the SPI flash. Must write exactly 256 bytes at a time. The start address must be 256-byte aligned.',
			argumentsTextOrdering=[['bin', 'If true (nonzero), expects to receive binary data, otherwise expects to receive an ASCII hex string'], ['addr', 'The address in the SPI flash to begin writing to. Must be 256-byte aligned.']],
			returnValuesTextOrder=None)
		
		s += '\\end{itemize}\n\n'

		# Misc
		s += '\\subsection{Miscellaneous Functions}\n'
		s += '\\begin{itemize}\n\n'

		s += self.generateForthCommand('rst', 'Performs a soft reset (turns on all memory cells and jumps to address 0 in the ROM, does not reset clocks or hardware)',
			argumentsTextOrdering=None,
			returnValuesTextOrder=None)
		
		s += self.generateForthCommand('clk', 'Measures selected clock frequency',
			argumentsTextOrdering=[['meastime', 'Measurement time. 0 = 1 s; 1 = 0.5 s; 2 = 0.25 s; 3 = 0.125 s'], ['clksel', 'Clock select. 0 = SMCLK; 1 = MCLK; 2 = LFXT; 3 = HFXT']],
			returnValuesTextOrder=[['freq', 'Selected clock frequency in Hz']])
		
		s += self.generateForthCommand('min', 'Returns minimum value of val2 and val1',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('max', 'Returns maximum value of val2 and val1',
			argumentsTextOrdering=[['val2', 'Signed integer'], ['val1', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('swpb', 'Swap bits 15 downto 8 with bits 7 downto 0 of TOS, also causes bits 31 downto 16 to all be 0',
			argumentsTextOrdering=[['val', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += self.generateForthCommand('swphw', 'Swap upper 16 bits with lower 16 bits of TOS',
			argumentsTextOrdering=[['val', 'Signed integer']],
			returnValuesTextOrder=[['ret', 'Return value']])
		
		s += '\\end{itemize}\n\n'

		# New Functions
		s += '\\subsection{Creating New Forth Functions}\n'
		s += 'To create a new Forth function on-the-fly, simply use the syntax ``' + self.truetype(': funcname definition ;') + '" where ``funcname" is the name of the new function and ``definition" is the body of the function. The new function may be called at any time after the semicolon (even before a new line, though it will not actually be executed until a new line) by typing the function name, just like all other Forth functions. New Forth functions can only add or remove variables from the stack and call other defined Forth functions. The arguments to custom Forth functions are the initial values on the stack that the custom function pops off the TOS. Likewise, the return values are any new values the custom function pushes to the TOS.\n\n'

		s += 'Listed below is an example program that increments the TOS by one when it is called:\n\n'
		s += self.truetype(': inc 1 + ;')

		# Conditionals
		s += '\\subsection{Conditionals}\n'
		s += 'The ' + self.truetype('if then') + ' sequence is a conditional which may only be used inside a newly defined function. The conditional is used with the syntax:\n\n'
		s += self.truetype('if procedureIfTrue then') + '\n\n'
		s += '\\noindent inside a function (do not forget the space and semicolon which must come after ' + self.truetype('then') + '). The ' + self.truetype('if') + ' function pops the TOS and then executes whatever is defined within ' + self.truetype('procedureIfTrue') + ' if and only if the TOS is true (nonzero). The ' + self.truetype('then') + ' function makrks the end of the conditional procedure. For example, a function to print the text ``cool" if the TOS is equal to 5 might look like this:\n\n'
		s += self.truetype(': cool? 5 == if 108 111 111 99 emit emit emit emit then ;') + '\n\n'
		s += 'The ' + self.truetype('else') + ' keyword may be inserted after ' + self.truetype('procedureIfTrue') + ' if you want to execute something if the conditional is false. The syntax then becomes:\n\n'
		s += self.truetype('if procedureIfTrue else procedureIfFalse then') + '\n\n'

		# Loops
		s += '\\subsection{Loops}\n'
		s += 'Forth has the equivalent of ' + self.truetype('while') + ' loops (or, more accurately, ' + self.truetype('do while') + ' loops) with its ' + self.truetype('begin until') + ' loops. ' + self.truetype('begin until') + ' loops may only be executed inside a newly defined function, and execute with the syntax:\n\n'
		s += self.truetype('begin loopProcedure until') + '\n\n'
		s += '\\noindent which first executes the loop procedure. When it gets to the ' + self.truetype('until') + ' statement, it then checks if the TOS is true (nonzero) or false (zero). If the TOS is false, it loops back to the beginning of the loop. If true, it exits the loop and continues on.\n\n'

		s += 'Forth also has the equivalent of ' + self.truetype('for') + ' loops with its ' + self.truetype('do loop') + ' procedure. Again, this may only be used inside a function. It uses the syntax:\n\n'
		s += self.truetype('stop start do loopProcedure loop') + '\n\n'
		s += '\\noindent where ' + self.truetype('stop') + ' is the index the loop stops on (it does NOT execute the loop procedure when the index is equal to ' + self.truetype('stop') + '), ' + self.truetype('start') + ' is the first loop index, and ' + self.truetype('loopProcedure') + ' is any functions or variables that you want to execute during the loop. There is a special function ' + self.truetype('i') + ' that may only be called from within a loop which pushes the loop index to the TOS. The functions ' + self.truetype('j') + ' and ' + self.truetype('k') + ' behave similarly, except they return the indices of the second and third nested loops respectively if you have nested loops. The ' + self.truetype('i')  + ' function always returns the index of the deepest (or most frequent) loop.\n\n'
		s += 'Below is an example Forth program that prints the numbers from 0 to 9 using a ' + self.truetype('do loop') + ' procedure:\n\n'
		s += self.truetype(': looptest 10 0 do i . loop ;')

		s += '\\newpage\n\n'
		return s
	
	def generateForthCommand(self, name:str, description:str, argumentsTextOrdering=None, returnValuesTextOrder=None, nameTruetype=True):
		s = ''
		args = []
		if argumentsTextOrdering is not None:
			args = argumentsTextOrdering
		
		rets = []
		if returnValuesTextOrder is not None:
			rets = returnValuesTextOrder
		
		# Make title
		s += '\\item \\textbf{Forth Function ``'
		if nameTruetype:
			s += self.truetype(name)
		else:
			s += name
		s += '" '

		usage = '( '
		for arg in args:
			usage += arg[0] + ' '
		usage += '-{}- '
		for ret in rets:
			usage += ret[0] + ' '
		usage += ')'

		s += self.truetype(usage)
		s += '}'
		s += '\n\n'

		# print description
		s += '\\noindent ' + description + '\n\n'

		# Print arguments
		if argumentsTextOrdering is None:
			s += '\\noindent Arguments: none\n\n'
		else:
			s += '\\noindent Arguments in order from TOS down (reverse text order):\n'
			s += '\\begin{enumerate}\n'
			for arg in reversed(args):
				s += '\item ' + self.truetype(arg[0]) + ': ' + arg[1] + '\n\n'
			s += '\\end{enumerate}\n\n'
		
		# Print return values
		if returnValuesTextOrder is None:
			s += '\\noindent Returns: nothing\n\n'
		else:
			s += '\\noindent Return values in order from TOS down (reverse text order):'
			s += '\\begin{enumerate}\n'
			for ret in reversed(rets):
				s += '\item ' + self.truetype(ret[0]) + ': ' + ret[1] + '\n\n'
			s += '\\end{enumerate}\n\n'

		return s
		

	def generateProgramming(self, memoryMap):
		s = ''

		s += '\\section{Uploading Program to SPI Flash} \\label{s:programming}\n\n'

		s += '\\subsection{SPI Flash Boot Process}\n'
		s += 'In order to boot in SPI flash mode, there must first be a vaild program stored in the SPI flash memory in the proper location. In SPI flash mode, the bootloader reads the data in the SPI flash memory starting at address ' + self.fmthex(memoryMap.RamStartAddress) + ' and copies every 32-bit word into RAM, also starting at address ' + self.fmthex(memoryMap.RamStartAddress) + '. This particular address is the beginning of the RAM on the MCU. The bootloader stops copying from the SPI flash once it copies the 32-bit word at address ' + self.fmthex(memoryMap.RamEndAddress - 3) + ', which is the last word in the RAM.\n\n'
		s += 'Note the distinction between copying 32-bit words as opposed to 8-bit bytes. Though bytes and words are both MSB-first, they are also transmitted starting with the lowest address to the greatest address from the SPI flash. If the bootloader copied every 8-bit byte, the transmission sequence it would expect would be:\n\n'
		s += 'byte0, byte1, byte2, byte3, byte4, byte5, byte6, byte7...\n\n'
		s += '\\noindent However, because the bootloader expects MSB-first 32-bit words, the sequence must be:\n\n'
		s +='byte3, byte2, byte1, byte0, byte7, byte6, byte5, byte4...\n\n'
		s +='\\noindent Therefore, the program data on the SPI flash must follow the 32-bit word sequence.\n\n'

		s += '\\subsection{Upload Process}\n'
		s += 'The Forth boot mode has a mechanism for writing data to the SPI flash, which may be used to upload a new program for use in the SPI flash boot mode. When in Forth boot mode, the flash write ' + self.truetype('fw') + ' function writes a page of data (which is exactly 256 bytes long and begins on an address that is a multiple of 256) to the SPI flash. The Forth function is used with the syntax:\n\n'
		s += self.truetype('bin addr fw') + '\n\n'
		s += 'If ' + self.truetype('bin') + ' is true (nonzero), the command expects 256 bytes of binary data to be transmitted over the UART. If false, it expects a 512-character long ASCII hex string representing the data to be transmitted over the UART. The ' + self.truetype('addr') + ' argument must be the address of the beginning of the 256-byte page, and must be aligned to a 256-byte boundary.\n\n'
		s += 'To execute the command, a newline (or line feed) character must be transmitted to the MCU over the UART. Once the command begins executing, it initiates some handshaking to ensure a proper transaction. The MCU prints a ' + self.truetype('\\$') + ' character to indicate it is ready for the page data to be transmitted. After that, you must transmit the page data in the format specified by the ' + self.truetype('bin') + ' argument. Remember to transmit the data in the proper order (byte3, byte2, byte1, byte0, byte7, byte6, byte5, byte4...). Once the page data has been transmitted, the MCU will compute a CRC value upon the data using the CRC16\\_CDMA2000 algorithm (polynomial = ' + self.fmthex(0xc857) + ', initial CRC value = ' + self.fmthex(0xffff) + ', no final XOR, no data reflection, no output reflection) and then transmit the CRC value as a 4-character long hex string. If this value matches your own CRC computation (or if you do not care and simply want it to write the data), transmit a single ' + self.truetype('Y') + ' character without anything else to tell the MCU to write the data to the SPI flash. Any other character will abort the process, leaving the SPI flash memory unchanged. You are technically supposed to wait an average of 10 ms (25 ms at the greatest) before writing more data to the SPI flash. However, the substantial handshaking and transmission times likely fulfill this requirement, and it is likely that no delay is needed.\n\n'
		s += 'If the entire page is blank, you may instead use the flash erase ' + self.truetype('fe') + ' function to erase the page, making every byte in the page equal to ' + self.fmthex(0xFF, minDigits=2) + '. This is much quicker than writing data to the SPI flash, and can speed up programming times substantially for smaller programs. The syntax to use it is:\n\n'
		s += self.truetype('conf addr fe') + '\n\n'
		s += 'If the ' + self.truetype('conf') + ' parameter is equal to 123, the function will erase the 256-byte page at address ' + self.truetype('addr') + ' (which must be 256-byte aligned) and then return 1. If not equal to 123, it will not erase the page and will return 0. You are technically supposed to wait an average of 6 ms (25 ms at the greatest) before another erase or write operation. Because the erase function is much quicker than the write function, it may become necessary to delay between erases at higher bauds.\n\n'
		s += 'You may read back the data stored on the SPI flash with the ' + self.truetype('fr') + ' function. See Section \\ref{ss:forthflash} for details.\n\n'

		s += 'In order to write an entire program to the SPI flash, you must write/erase a total of ' + str(memoryMap.RamSize // 256) + ' pages beginning with page address ' + self.fmthex(memoryMap.RamStartAddress) + ' and ending with page address ' + self.fmthex(memoryMap.RamEndAddress - 255) + '. After the data is written, you may execute the newly uploaded program by putting the MCU in reset, setting the BOOT pin to SPI flash mode, and taking the chip out of reset. Or, you can simply set the BOOT pin and move the program counter to address ' + self.fmthex(0) + ', which may be done with the ' + self.truetype('rst') + ' Forth function.\n\n'

		s += 'It is highly suggested to use the provided Python program ' + self.truetype('forthprog.py') + ' to upload new programs to the SPI flash, which takes an Intel hex file containing the new program and sends it to the MCU and the SPI flash using the process described above.\n\n'

		s += '\\newpage\n\n'
		return s
	
	def generateSoftware(self, memoryMap):
		s = ''

		s += '\\section{Software Development and Build Process} \\label{s:software}\n\n'

		s += '\\subsection{The RISC-V Toolchain and its Extensions}\n'
		s += 'To compile software for the picorv32 RISC-V CPU, you will need the RISC-V GNU toolchain, which is an open source compiler suite that supports a variety of languages. The base toolchain, called RV32I, contains the fewest instructions and is in general the simplest. The ``I" suffix stands for ``integer", meaning that the toolchain supports instructions that deal with basic integer arithmetic, excluding multiplication, division, and modulo instructions. All instructions in RV32I are 32 bits long, without exception. Two extensions for the compiler exist that may be supported by this picorv32 implementation: integer multiplication extension [M], and the the compressed instruction set extension [C] (see Section \\ref{s:config} to see if this MCU supports the extensions). The integer multiplication extension adds multiply, divide, and modulo instructions to the instruction set, provided that the CPU includes hardware to perform such operations (again, see Section \\ref{s:config}). If the CPU does not contain such hardware, then the [M] extension cannot be used. In that case, the compiler would infer software emulation of the instructions whenever multiplication, division, or modulo is needed, at the cost of computation time. The compressed instruction set extension adds duplicates of many of the instructions in RV32I, except the duplicates use only 16 bits rather than 32. According to the RISC-V ISA documentation, using the [C] extension will likely reduce program sizes by about 20\\% to 30\\%. Not all instructions can be compressed, however, and if those that are not compressed do not fall on a 4-byte aligned memory address, they will take an additional two clock cycles to execute.\n\n'

		s += '\\subsection{Getting the RISC-V Toolchain on Linux} \\label{ss:linuxinstall}\n'
		s += 'You can find the source code for the RISC-V toolchain at \\href{https://github.com/riscv/riscv-gnu-toolchain}{https://github.com/riscv/riscv-gnu-toolchain}, which also contains instructions for building the toolchain. However, the website instructions do not give directions for including the compressed instruction set extension [C]. Therefore, it is suggested to follow the procedure below to download and build the RV32IMC toolchain. Once you have the toolchain with both extensions, you can switch off the [M] and/or [C] extensions with the ' + self.truetype('-march', small=True) + ' compiler flag (more on that later). It is suggested that you use Ubuntu or Linux Mint, for which the software dependencies needed to build the toolchain can be fulfilled with:\n\n\\noindent' + self.linux('sudo apt install autoconf automake autotools-dev curl libmpc-dev libmpfr-dev libgmp-dev gawk build-essential bison flex texinfo gperf libtool patchutils bc zlib1g-dev libexpat-dev') + '\n\nThe instructions are as follows:\n\n'
		s += '\\begin{enumerate}\n'
		s += '\\item Switch to your home directory with ' + self.linux('cd ~') + '\n'
		s += '\\item Make a new directory with ' + self.linux('mkdir riscv-download') + ' and go into it with ' + self.linux('cd riscv-download') + '\n'
		s += '\\item Download the RV32IMC toolchain with ' + self.linux(r'git clone --recursive https://github.com/riscv/riscv-gnu-toolchain riscv-gnu-toolchain-rv32imc') + '\n'
		s += '\\item Go into the new directory with ' + self.linux('cd riscv-gnu-toolchain-rv32imc') + '\n'
		s += '\\item Create a build directory with ' + self.linux('mkdir build') + ' and go into the new build directory with ' + self.linux('cd build') + '\n'
		s += '\\item Configure the build with ' + self.linux('../configure --with-arch=rv32imc --prefix=/opt/riscv/rv32imc') + '\n'
		s += '\\item Begin the build process with ' + self.linux('sudo make') + ' (this will take quite a while. If you wish to speed up the process, you can allocate more CPU cores to the build process by using ' + self.truetype('make -jn', small=True) + ' instead of ' + self.truetype('make', small=True) + ' where n can be replaced by the number of CPU cores you want to use to build the toolchain.). Once the build process has finished successfully, the toolchan will be located at ' + self.linux('/opt/riscv/rv32imc') + '\n'
		s += '\\item Add a permanent environment variable to your system that defines the location of the ' + self.truetype('riscv') + ' directory (perhaps in your ' + self.truetype('.bashrc') + ' script) with something like ' + self.linux('export RISCV=/opt/riscv') + 'You may also wish to add the ' + self.truetype('/opt/riscv/rv32imc/bin') + ' directory to your PATH, though this is optional.'
		s += '\\item You may now safely delete the ' + self.truetype('riscv-download')  + ' directory with ' + self.linux('sudo rm -rf ~/riscv-download') + '\n'
		s += '\\end{enumerate}\n\n'



		s += '\\subsection{Getting the RISC-V Toolchain on Windows}\n'
		s += 'The RISC-V toolchain has no official support for Windows, but several options exist to get it working. For Windows 10 users, it is recommended to install the Windows Subsystem for Linux (WSL) in Ubuntu mode, which can be found in the Microsoft Store app. Then, in WSL, follow the installation instructions in Section \\ref{ss:linuxinstall}. You must then use WSL to compile all software for the RISC-V MCU.\n\n'
		s += 'If you have an older version of Windows, it is suggested that you use an Ubuntu or Linux Mint virtual machine to build the RISC-V toolchain and compile your MCU software.'

		s += '\\subsection{Getting the RISC-V Toolchain on macOS}\n'
		s += 'macOS requires you to install the following dependencies with Homebrew before building the RISC-V toolchain: ' + self.linux('brew install gawk gnu-sed gmp mpfr libmpc isl zlib expat') + '\n\n'
		s += 'Furthermore, the build process requires you to use a case-sensitive filesystem. However, the default macOS filesystem is case-insensitive, which would cause the build to fail. The simplest approach is to create and mount a new disk image with a case insensitive format. Make sure that the mount point does not contain spaces. After that, the installation procedure is similar to that described in Section \\ref{ss:linuxinstall}.\n\n'
		s += 'Note that the author did not test the RISC-V toolchain on macOS. Your results may vary.\n\n'

		s += '\\subsection{Compilation}\n'
		s += 'The RISC-V toolchain includes a GCC compiler. Thus, the compilation process is similar to other toolchains that use GCC. To compile a source file into an object file, use:\n'
		s += self.linux('riscv32-unknown-elf-gcc -c $CFLAGS srcFile -o objectFile.o') + '\n'
		s += '\\noindent where ' + self.truetype('\\$CFLAGS') + ' should be replaced by any compilation flags, ' + self.truetype('srcFile') + ' is the source code file (C, C++, assembly, or other GCC-supported languages), and ' + self.truetype('objectFile.o') + ' is the output object file. The compiler determines which launguage is used in a source file by the file extension (' + self.truetype('.c') + ' is for C, ' + self.truetype('.cpp') + ' is for C++, ' + self.truetype('.S') + ' is for assembly code which must be preprocessed, and ' + self.truetype('.s') + ' is for assembly code which is not preprocessed).\n\n'

		s += 'There are several compilation flags that are suggested:\n'
		s += '\\begin{itemize}\n'
		s += '\\item ' + self.truetype('-march=rv32imc') + ' , the architecture flag. This specifies which extensions are enabled in the compilation process. You may only include ``m" and/or ``c" if your MCU implementation supports it.\n'
		s += '\\item ' + self.truetype('-Os') + ' , the optimize for space flag. Attempts to shrink the program size.\n'
		s += '\\item ' + self.truetype('-O$<$number$>$') + ' , the optimization level. Lower numbers perform less optimization, higher include more.'
		s += '\\item ' + self.truetype('-I $<$include_directory$>$') + ' , the include directory flag. Adds the specified directory to the list of directories that have header files in them. Any files in the include directory may be included with the ' + self.truetype('\\#include $<$filename.h$>$') + ' preprocessor directive.\n'
		s += '\\item ' + self.truetype('-g') + ' , the GDB debugger enable flag. While the picorv32 core does not support hardware debugging, adding the ' + self.truetype('-g') + ' flag to both the compiler and linker commands will allow the ' + self.truetype('.lst') + ' file to show the assembly commands your code compiles into.\n'
		s += '\\end{itemize}\n\n'

		s += 'You must compile every source file that you wish to use in your project. If your project is in C or C++, it is suggested that you use the provided ' + self.truetype('start.S') + ' assembly file to call your main function. This assembly file needs to have its first instruction at address ' + self.fmthex(memoryMap.RamProgramStartAddress) + ', so it must be the first file to be given to the linker. You must have one and only one ' + self.truetype('int main()') + ' function throughout all of your source files in a single project. For C++ projects, you need to start the main function with ' + self.truetype('extern "C" int main()') + ' to prevent the C++ compiler from name-mangling the main function.\n\n'

		s += '\\subsection{Linking}\n'
		s += 'Once all source files have been compiled, they must be linked to produce the output program binary file, the ' + self.truetype('.elf') + ' file. The linker assigns memory addresses to every variable and function. The MCU contains no writable non-volatile memory, so the program and the variables all share the RAM (with a notable exception for the bootloader and Forth interpreter stored on the ROM). The linker must be aware of the RAM and ROM start address and size, the interrupt vector table (IVT) start address and size (along with the address of each ISR pointer within the IVT), the first program instruction address that the bootloader jumps to after loading the program into RAM, and the address of the master interrupt handler. \n\n'
		s += 'Defining the aforementioned memory segments and addresses is done using a linker script. It is highly suggested to use the provided linker script ' + self.truetype('MCU.ld') + ' and its include files and tweak it to suit your need.\n\n'
		s += 'To execute the linker, use:\n'
		s += self.linux('riscv32-unknown-elf-gcc $LFLAGS $OBJECTS -o program.elf') + '\n'
		s += '\\noindent where ' + self.truetype('\\$LFLAGS') + ' is a list of linker flags, ' + self.truetype('\\$OBJECTS') + ' is a list of all the compiled object files needed for the project, and ' + self.truetype('program.elf') + ' is the output ELF binary containing the program.\n\n'
		s += 'There are several linker flags that are suggested:\n'
		s += '\\begin{itemize}\n'
		s += '\\item ' + self.truetype('-march=rv32imc') + ' , the architecture flag. This specifies which extensions are enabled in the compilation process. You may only include ``m" and/or ``c" if your MCU implementation supports it.\n'
		s += '\\item ' + self.truetype('-flto') + ' , the link-time optimization flag. This instructs the linker to perform optimizations to the final binary.\n'
		s += '\\item ' + self.truetype('-nostdlib') + ' , which disables the use of the standard library for linking, decreasing software bloat. However, using the flag precludes using standard library functions such as software emulation of integer multiplication and division, floating point numbers, initialization routines, memory allocation, etc. It is suggested that you only use this flag if you have a specific need to reduce the software size.\n'
		s += '\\item ' + self.truetype('-T linker_script.ld') + ' , the path to the linker script\n'
		s += '\\item ' + self.truetype('-Map mapfile.map') + ' , the path to the output map file, which contains the symbol table for your project with their addresses\n'
		s += '\\item ' + self.truetype('-L linkerfiles_dir') + ', the path to the linker scripts directory that contains any files that are included in the main linker script\n'
		s += '\\item ' + self.truetype('-g') + ' , the GDB debugger enable flag. While the picorv32 core does not support hardware debugging, adding the ' + self.truetype('-g') + ' flag to both the compiler and linker commands will allow the ' + self.truetype('.lst') + ' file to show the assembly commands your code compiles into.\n'
		s += '\\end{itemize}\n\n'


		s += '\\subsection{Intel Hex File Generation}\n'
		s += 'Once the final ELF file has been created from the linker, an Intel hex file can be created, which converts the binary program data into an easy-to-read ASCII file. Furthermore, the Python package ``IntelHex" can read the file, allowing you to use Python to upload a new program to the SPI flash. A Python program that utilizes IntelHex to upload new programs, called ' + self.truetype('forthprog.py') + ', is provided.'


		s += '\\subsection{A Note on Using C++}\n'
		s += 'C++ generates some extra data sections that C and assembly do not use. In particular, it generates the .eh\\_frame section, which is used for exception handling. You may not need exception handling, in which case you can pass in the compiler flags:\n'
		s += self.linux('-fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables') + '\n'
		s += '\\noindent which will significantly reduce the size of .eh\\_frame. If you wish to eliminate it entirely, you can create a phony section in the linker script at an unused memory address and point the .eh\\_frame section to it.\n\n'


		s += '\\newpage\n\n'
		return s
	
	def generateMemoryMap(self, memoryMap):
		s = ''
		
		s += '\\section{Memory Map}\n\n'
		s += '\\begin{bytefield}{8}\n'
		s += '\\memsection{' + self.fmthex(memoryMap.RomStartAddress, minDigits=5, truetype=False) + '}{' + self.fmthex(memoryMap.RomEndAddress, minDigits=5, truetype=False) + '}{3}{ROM'  + r' \\ ' + 'Size = ' + str(memoryMap.RomSize // 1024) + ' KiB}' + r' \\' + '\n'
		if memoryMap.PeripheralMemoryStartAddress - memoryMap.RomEndAddress != 1:
			s += '\\memsection{' + self.fmthex(memoryMap.RomEndAddress + 1, minDigits=5, truetype=False) + '}{' + self.fmthex(memoryMap.PeripheralMemoryStartAddress - 1, minDigits=5, truetype=False) + r'}{3}{\textit{Unused}}' + r' \\' + '\n'
		s += '\\memsection{' + self.fmthex(memoryMap.PeripheralMemoryStartAddress, minDigits=5, truetype=False) + '}{' + self.fmthex(memoryMap.PeripheralMemoryEndAddress, minDigits=5, truetype=False) + '}{3}{Peripherals' + r' \\ ' + 'Size = ' + str(memoryMap.PeripheralMemorySize // 1024) + ' KiB}' + r' \\' + '\n'
		if memoryMap.RamStartAddress - memoryMap.PeripheralMemoryStartAddress != 1:
			s += '\\memsection{' + self.fmthex(memoryMap.PeripheralMemoryEndAddress + 1, minDigits=5, truetype=False) + '}{' + self.fmthex(memoryMap.RamStartAddress - 1, minDigits=5, truetype=False) + r'}{3}{\textit{Unused}}' + r' \\' + '\n'
		s += '\\begin{rightwordgroup}{RAM (Total size = ' + str(memoryMap.RamSize // 1024) + ' KiB)}\n'
		for slot in memoryMap.RamMemorySlotsUsed:
			s += '\\memsection{' + self.fmthex(slot * memoryMap.RamMemorySlotSize, minDigits=5, truetype=False) + '}{' + self.fmthex(((slot + 1) * memoryMap.RamMemorySlotSize) - 1, minDigits=5, truetype=False) + '}{3}{SRAM' + '{:02}'.format(slot) + r' \\ ' + 'Size = ' + str(memoryMap.RamMemorySlotSize // 1024) + ' KiB}' + r' \\' + '\n'
		s = s[:-3] + '\n'	# Remove the \\ from the previous line
		s += '\\end{rightwordgroup}' + r' \\' + '\n'
		s += '\\end{bytefield}\n\n'
		
		s += 'The ROM cell contains boot code, which is read-only. Each SRAM cell can be read or written to, and may contain both program and variable information, if desired. Each SRAM and ROM cell can be individually powered off or on using the SYSTEM peripheral. When powered off, the cells use less power and cannot be read or written to. SRAM cells that are powered off do not retain their previous data, and the data becomes undefined.\n\n'
		s += 'The master interrupt handler begins at address ' + self.fmthex(memoryMap.PROGADDR_IRQ) + ', which is called when any interrupt occurs. The master interrupt handler then determines which interrupt service routine (ISR) it needs to call and looks up the particular ISR address in the interrupt vector table (IVT), which begins at address ' + self.fmthex(memoryMap.VectorsStartAddress) + ' and contains thirty-two 32-bit pointers to the ISRs.'
		
		s += '\\newpage\n\n'
		
		return s
	
	def generateInterrupts(self, memoryMap, useAlternatingColoredRows=True):
		s = ''
		
		s += '\\section{Interrupts}\n\n'
		
		s += r'\begin{tabularx}{\textwidth}{ l l }' + '\n'
		s += r'\textbf{Priority} & \textbf{Interrupt Source}' + r' \\ \hline' + '\n'
		s += r'0 & CPU Internal Timer \\' + '\n'
		s += r'\rowcolor{tablehighlightcolor}1 & EBREAK, ECALL, or Illegal Instruction \\' + '\n'
		s += r'2 & Bus Error (unaligned memory access) \\' + '\n'

		interruptPeripherals = []
		for p in memoryMap.Peripherals:
			if p.InterruptPriority is not None:
				interruptPeripherals.append(p)
		
		interruptPeripherals.sort(key=lambda p: p.InterruptPriority)

		thisRowColored = True

		for p in interruptPeripherals:
			if useAlternatingColoredRows is True and thisRowColored is True:
				s += r'\rowcolor{tablehighlightcolor}'
			
			s += str(p.InterruptPriority) + ' & ' + p.Name + r'\\' + '\n'

			thisRowColored = not thisRowColored
		
		s += r'\end{tabularx}' + '\n\n'

		s += 'The CPU has 32 available interrupt slots, which may or may not be populated with an actual interrupt signal. Each interrupt slot can be individually masked to disable it using the custom ' + self.truetype('maskirq') + ' assembly instruction (any bit that is set to 1 masks, or disables, the interrupt). Furthermore, the CPU can be instructed to wait until an interrupt occurs using the custom ' + self.truetype('waitirq')  + ' assembly instruction (note that the ' + self.truetype('waitirq') + ' instruction does not cause the CPU to go to sleep; it merely causes the CPU to jump back to the ' + self.truetype('retirq') + ' instruction repeatedly until an interrupt occurs).\n\n'
		s += 'In general, a peripheral will get into a state that asserts its interrupt signal, which immediately causes the CPU to jump (move the program counter) to address ' + self.fmthex(memoryMap.PROGADDR_IRQ) + ', which must be the start address of the master interrupt handler. The master interrupt handler is responsible for determining which interrupt has occurred, choosing the correct interrupt service routine (ISR) to call, and calling the ISR by looking up its address in the interrupt vector table (IVT). The user is responsible for placing the master interrupt handler at the correct address (' + self.fmthex(memoryMap.PROGADDR_IRQ) + '), and must program the master interrupt handler to do the following: save the 32 CPU registers to RAM, determine which interrupts are pending, call the appropriate ISR(s), load the CPU registers back from RAM, and return execution to its prior place by moving the program counter back to where it was before the interrupt occurred. Furthermore, the user is also responsible for placing the peripherals into a state such that their interrupt signals are no longer asserted while executing the ISRs. If the user fails to do so and the peripheral continues to assert its interrupt signal, then the CPU will jump back to the master interrupt handler immediately after the prior call to the master interrupt handler returns. This will most likely cause the MCU to get stuck executing the master interrupt handler forever without executing any of the main code.\n\n'
		s += 'If an interrupt occurs while the CPU is off (in sleep mode), then the CPU will turn on (exit sleep mode) until the custom ' + self.truetype('retirq') + ' assembly instruction is executed, whereupon the CPU will turn back off (re-enter sleep mode) unless instructed otherwise. The CPU clock is disabled while the CPU is off (in sleep mode), and the CPU registers and program counter retain their values. If the clock that sources MCLK (and by extension, the CPU clock) is powered down or disabled while the CPU is in sleep mode, then any interrupt will automatically power up and enable the source clock for the duration of the interrupt. The clocks and CPU on/off states can be controlled in the SYSTEM peripheral. Note that if the clock that sources SMCLK is disabled, peripherals may not be able to change the state of their interrupt signals.\n\n'
		s += 'Note that all interrupts are masked (disabled) when the MCU boots. In order to use/enable interrupts, you must unmask them with the custom ' + self.truetype('maskirq') + ' assembly instruction. Furthermore, the peripherals that generate the interrupts must also be configured to enable interrupts in order for their interrupts to occur.\n\n'
		s += 'Though it is not strictly required, it is recommended to create an interrupt vector table (IVT) that stores the 32-bit pointer (or memory address) to each ISR in order of priority. As there are 32 available interrupt slots, the IVT occupies 128 bytes of RAM. The automatic code generation tool generates the IVT by default at the very beginning the the RAM, though the user is not required to use it or populate it. If the IVT is used, the master interrupt handler should use it to call the appropriate ISR(s). The auto-generated linker script defines the locations for each element of the IVT, and the memory map C/C++ header file provides a macro to place a pointer to the ISR in the appropriate IVT element.'
		

		s += '\\newpage\n\n'
		return s
	
	def generatePinConfiguration(self, memoryMap, useAlternatingColoredRows=True):
		s = ''
		
		s += '\\section{GPIO Pins Configuration}\n\n'
		s += '\\begin{tabularx}{\\textwidth}{ l l l l l l X }\n'
		s += r' & \textbf{Primary} & \textbf{Secondary} & \multicolumn{4}{c}{\textbf{\textit{Reset Values}}}' + r' \\' + r' \cline{4-7}' + '\n'
		s += r'\textbf{Pin} & \textbf{Function} & \textbf{Function} & \textbf{SEL} & \textbf{OUT} & \textbf{DIR} & \textbf{REN}' + r' \\ \hline' + '\n'
		
		gpioPeripherals = []
		for p in memoryMap.Peripherals:
			if p.IsGPIO():
				gpioPeripherals.append(p)

		thisRowColored = False

		for i, p in enumerate(gpioPeripherals):
			for j, pin in enumerate(p.Pins):
				l = ''

				if useAlternatingColoredRows is True and thisRowColored is True:
					l += r'\rowcolor{tablehighlightcolor}'

				l += 'P' + p.GetGPIOPortLabel() + '.' + str(pin.PinNumber) + r' & '
				
				if len(pin.PrimaryName) > 0:
					l += self.truetype(pin.PrimaryName) + r' & '
				else:
					l += '--' + r' & '
				
				if len(pin.FuncName) > 0:
					l += self.truetype(pin.FuncName) + r' & '
				else:
					l += '--' + r' & '
				
				if pin.RstSEL == 1:
					l += self.truetype('1') + r' (\textit{Secondary})' + r' & '
				else:
					l += self.truetype('0') + r' (\textit{Primary})' + r' & '
				
				if pin.RstOUT == 1:
					l += self.truetype('1') + r' (\textit{High})' + r' & '
				else:
					l += self.truetype('0') + r' (\textit{Low})' + r' & '
				
				if pin.RstDIR == 1:
					l += self.truetype('1') + r' (\textit{Output})' + r' & '
				else:
					l += self.truetype('0') + r' (\textit{Input})' + r' & '
				
				if pin.RstREN == 1:
					l += self.truetype('1') + r' (\textit{Enabled})' + r' \\'
				else:
					l += self.truetype('0') + r' (\textit{Disabled})' + r' \\'
				
				if ((i + 1) < len(gpioPeripherals)) and ((j + 1) == len(p.Pins)):
					# This is not the last GPIO port, but is the last pin in the port
					l += r' \hline'
				l += '\n'
				
				s += l

				thisRowColored = not thisRowColored
		# Remove the \\ from the last entry
		s = s[:-3] + '\n'
		s += '\\end{tabularx}\n'
		
		s += '\\newpage\n\n'
		
		return s
	
	def generateConfiguration(self, memoryMap):
		s = ''

		s += r'\section{System Configuration} \label{s:config}' + '\n'
		s += '''The microcontroller (MCU) described in this document utilizes the picorv32 CPU core, a 32-bit RISC-V processor. The microcontroller is composed of the RISC-V CPU, a ROM that contains boot software and a forth interpreter, RAM memory cell(s), and several peripherals. The MCU hardware is configurable using a custom automatic code generation tool, which also automatically generates this user guide document to reflect its configuration.

		The following list details the MCU configuration:\n'''
		
		s += r'\begin{itemize}' + '\n'
		s += r'\item Chip Name: ' + memoryMap.AsicName.title() + '\n'
		s += r'\item Compatible with RISC-V compiler RV32I'
		if memoryMap.ENABLE_MUL or memoryMap.ENABLE_FAST_MUL:
			s += '[M]'
		if memoryMap.COMPRESSED_ISA:
			s += '[C]'
		s += '\n'
		s += r'\item Contains 32 CPU registers, each of size 32-bit' + '\n'
		if memoryMap.ENABLE_REGS_DUALPORT:
			s += r'\item Utilizes dual-port CPU registers' + '\n'
		else:
			s += r'\item Utilizes single-port CPU registers' + '\n'
		if memoryMap.BARREL_SHIFTER:
			s += r'\item Utilizes a barrel shifter in the ALU, which produces fast shifting operations' + '\n'
		else:
			if memoryMap.TWO_STAGE_SHIFT:
				s += r'\item Utilizes a two-stage shifter in the ALU, which produces medium speed shifting operations' + '\n'
			else:
				s += r'\item Utilizes a multi-stage shifter in the ALU, which is slow' + '\n'
		if memoryMap.COMPRESSED_ISA:
			s += r'\item Utilizes the additional compressed instruction set and allows the use of the [C] compiler extension. Allowing the compiler to use the [C] extension reduces executable code size, but also takes the processor longer to fetch 32-bit long instructions that are aligned on a 2 but not 4 byte boundary from memory.' + '\n'
		else:
			s += r'\item Does not utilize the additional compressed instruction set, and the [C] compiler extension is not allowed. Any compressed instructions will generate an EBREAK interrupt, which if left unhandled, will trap the CPU.'
		if memoryMap.ENABLE_FAST_MUL:
			s += r'\item Utilizes a fast 32-bit hardware signed integer multiplier in the ALU and allows the use of the [M] compiler extension' + '\n'
			if memoryMap.ENABLE_DIV:
				s += r'\item Utilizes a medium speed 32-bit hardware signed integer divider and remainder calculator in the ALU' + '\n'
		else:
			if memoryMap.ENABLE_MUL:
				s += r'\item Utilizes a medium speed 32-bit hardware signed integer multiplier in the ALU and allows the use of the [M] compiler extension' + '\n'
				if memoryMap.ENABLE_DIV:
					s += r'\item Utilizes a medium speed 32-bit hardware signed integer divider and remainder calculator in the ALU' + '\n'
			else:
				s += r'\item No hardware multiplier is included in the ALU, and the [M] compiler extension is not allowed. Any multiply instructions will generate an EBREAK interrupt, which if left unhandled, will trap the CPU.' + '\n'
				s += r'\item No hardware divider/remainder calculator is included in the ALU. Any divide or modulo operations will generate an EBREAK interrupt, which if left unhandled, will trap the CPU.' + '\n'
		s += r'\item The peripherals can interrupt the CPU process to execute interrupt service routines' + '\n'
		s += r'\item When any interrupt occurs, the CPU immediately jumps (sets the program counter) to address ' + self.fmthex(memoryMap.PROGADDR_IRQ) + '. Your software must put the master interrupt handler at this location.\n'
		if memoryMap.ENABLE_IRQ_QREGS:
			s += r'\item Four extra CPU registers are included to make interrupt service routines execute faster' + '\n'
		

		s += r'\end{itemize}' + '\n\n'
		s += r'\newpage' + '\n\n'

		return s
	
	def truetype(self, txt, bold=False, small=True, zeroslash=False, visiblespace=False):
		options = '\\ttfamily '
		if bold is True:
			options += '\\bfseries '
		if small is True:
			options += '\\footnotesize '
		
		txt = txt.replace('_', '\\_')
		if visiblespace is True:
			txt = txt.replace(' ', '{\\textvisiblespace}')
		
		if zeroslash is True:
			txt = txt.replace('0', '{\\pmzeroslash}')
		
		return '{' + options + txt + '}'
	
	def linux(self, txt):
		return '\\begin{lstlisting}\n' + txt + '\n\\end{lstlisting}\n'

	def fmthex(self, num, minDigits=4, bold=False, small=False, truetype=True):
		fmtstr = '{:0' + str(minDigits) + 'x}'
		s = '0x' + fmtstr.format(num).upper()
		if truetype is True:
			s = self.truetype(s, bold=bold, small=small)
		return s
	
	def fmtbin(self, num, minDigits=8, noPrefix=False, bold=False, small=False, truetype=True):
		fmtstr = '{:0' + str(minDigits) + 'b}'
		s = ''
		if noPrefix is False:
			s += '0b'
		s += fmtstr.format(num).upper()
		if truetype is True:
			s = self.truetype(s, bold=bold, small=small)
		return s